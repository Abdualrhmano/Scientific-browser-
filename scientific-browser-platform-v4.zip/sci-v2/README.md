# Scientific Browser v2

A scientific search platform that queries live scholarly APIs and surfaces related learning videos.

## Run

```bash
npm install
npm run dev
```
