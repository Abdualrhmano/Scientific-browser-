'use client';

import { create } from 'zustand';
import { createJSONStorage, persist } from 'zustand/middleware';
import type { SearchFilters, SearchResponse, ScientificPaper, ScientificVideo } from '@/lib/types';

const defaultFilters: SearchFilters = {
  query: '',
  source: 'all',
  yearFrom: '',
  yearTo: '',
  openAccessOnly: false,
  sortBy: 'relevance',
  limit: 12,
};

interface AppState {
  filters: SearchFilters;
  isSearching: boolean;
  results: ScientificPaper[];
  videos: ScientificVideo[];
  selectedPaper: ScientificPaper | null;
  savedPapers: ScientificPaper[];
  paperNotes: Record<string, string>;
  queryHistory: string[];
  darkMode: boolean;
  errors: string[];
  setFilters: (patch: Partial<SearchFilters>) => void;
  performSearch: () => Promise<void>;
  selectPaper: (paper: ScientificPaper | null) => void;
  toggleSavePaper: (paper: ScientificPaper) => void;
  setDarkMode: (value: boolean) => void;
  clearHistory: () => void;
  removeSavedPaper: (paperId: string) => void;
  setPaperNote: (paperId: string, note: string) => void;
  clearPaperNote: (paperId: string) => void;
}

function normalizeQuery(query: string): string {
  return query.trim().replace(/\s+/g, ' ');
}

export const useAppStore = create<AppState>()(
  persist(
    (set, get) => ({
      filters: defaultFilters,
      isSearching: false,
      results: [],
      videos: [],
      selectedPaper: null,
      savedPapers: [],
      paperNotes: {},
      queryHistory: [],
      darkMode: true,
      errors: [],
      setFilters: (patch) => set((state) => ({ filters: { ...state.filters, ...patch } })),
      performSearch: async () => {
        const { filters } = get();
        const query = normalizeQuery(filters.query);
        if (!query) {
          set({ results: [], videos: [], errors: [] });
          return;
        }

        set((state) => ({
          isSearching: true,
          errors: [],
          filters: { ...state.filters, query },
          queryHistory: [query, ...state.queryHistory.filter((item) => item !== query)].slice(0, 10),
        }));

        try {
          const url = new URL('/api/search', window.location.origin);
          url.searchParams.set('q', query);
          url.searchParams.set('source', filters.source);
          if (filters.yearFrom) url.searchParams.set('yearFrom', filters.yearFrom);
          if (filters.yearTo) url.searchParams.set('yearTo', filters.yearTo);
          url.searchParams.set('openAccessOnly', String(filters.openAccessOnly));
          url.searchParams.set('sortBy', filters.sortBy);
          url.searchParams.set('limit', String(filters.limit));

          const response = await fetch(url.toString(), {
            headers: { Accept: 'application/json' },
          });

          if (!response.ok) {
            throw new Error(`Search request failed (${response.status})`);
          }

          const data = (await response.json()) as SearchResponse;
          set({
            results: data.results,
            videos: data.videos,
            errors: data.errors,
            selectedPaper: data.results[0] ?? null,
            isSearching: false,
          });
        } catch (error) {
          set({
            isSearching: false,
            errors: [error instanceof Error ? error.message : 'Search failed'],
          });
        }
      },
      selectPaper: (paper) => set({ selectedPaper: paper }),
      toggleSavePaper: (paper) => {
        const exists = get().savedPapers.some((item) => item.id === paper.id);
        set({
          savedPapers: exists
            ? get().savedPapers.filter((item) => item.id !== paper.id)
            : [paper, ...get().savedPapers],
        });
      },
      setDarkMode: (value) => set({ darkMode: value }),
      clearHistory: () => set({ queryHistory: [] }),
      removeSavedPaper: (paperId) => set({ savedPapers: get().savedPapers.filter((paper) => paper.id !== paperId) }),
      setPaperNote: (paperId, note) =>
        set((state) => ({
          paperNotes: {
            ...state.paperNotes,
            [paperId]: note,
          },
        })),
      clearPaperNote: (paperId) =>
        set((state) => {
          const next = { ...state.paperNotes };
          delete next[paperId];
          return { paperNotes: next };
        }),
    }),
    {
      name: 'scientific-browser-v2-store',
      storage: createJSONStorage(() => localStorage),
      partialize: (state) => ({
        savedPapers: state.savedPapers,
        paperNotes: state.paperNotes,
        queryHistory: state.queryHistory,
        darkMode: state.darkMode,
      }),
    }
  )
);
