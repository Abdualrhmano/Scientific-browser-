'use client';

import { useMemo, useState, type ReactNode } from 'react';
import Link from 'next/link';
import {
  ArrowLeft,
  ArrowRightLeft,
  Bookmark,
  BookmarkCheck,
  Copy,
  ExternalLink,
  FileSearch,
  FileText,
  Languages,
  LayoutGrid,
  Loader2,
  PanelLeft,
  Rocket,
  Sparkles,
  ScrollText,
} from 'lucide-react';
import type { ScientificPaper } from '@/lib/types';
import { useAppStore } from '@/store/useAppStore';
import { authorList, formatSourceLabel, safeUrl, yearLabel } from '@/lib/format';
import { buildKeyInsights, buildReadingSummary } from '@/lib/insights';
import { citationFormats } from '@/lib/citations';
import { buildVideoRecommendations } from '@/lib/videos';
import { translateScientificText } from '@/lib/translate';

function SectionTitle({ eyebrow, title, description }: { eyebrow: string; title: string; description?: string }) {
  return (
    <div className="space-y-2">
      <div className="text-xs font-medium uppercase tracking-[0.22em] text-slate-400">{eyebrow}</div>
      <h2 className="text-2xl font-semibold text-white">{title}</h2>
      {description ? <p className="max-w-3xl text-sm leading-7 text-slate-400">{description}</p> : null}
    </div>
  );
}

function Stat({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-2xl border border-white/10 bg-white/5 p-4">
      <div className="text-[11px] uppercase tracking-[0.2em] text-slate-400">{label}</div>
      <div className="mt-2 break-words text-sm font-semibold text-white">{value}</div>
    </div>
  );
}

function ActionButton({
  children,
  onClick,
  href,
  variant = 'ghost',
}: {
  children: ReactNode;
  onClick?: () => void;
  href?: string;
  variant?: 'ghost' | 'primary';
}) {
  const base =
    variant === 'primary'
      ? 'bg-primary-500 text-white hover:bg-primary-400 border-primary-400/20'
      : 'border-white/10 bg-white/5 text-slate-100 hover:bg-white/10';
  const classes = `inline-flex items-center justify-center gap-2 rounded-2xl border px-4 py-3 text-sm font-medium transition ${base}`;
  if (href) {
    return (
      <a href={href} target="_blank" rel="noreferrer" className={classes}>
        {children}
      </a>
    );
  }
  return (
    <button type="button" onClick={onClick} className={classes}>
      {children}
    </button>
  );
}

function CodeBlock({ value }: { value: string }) {
  const [copied, setCopied] = useState(false);
  return (
    <div className="rounded-2xl border border-white/10 bg-[#0a1220] p-4">
      <pre className="overflow-auto whitespace-pre-wrap break-words text-sm leading-7 text-slate-200">{value}</pre>
      <div className="mt-3 flex justify-end">
        <button
          type="button"
          onClick={async () => {
            await navigator.clipboard.writeText(value);
            setCopied(true);
            window.setTimeout(() => setCopied(false), 1500);
          }}
          className="inline-flex items-center gap-2 rounded-xl border border-white/10 bg-white/5 px-3 py-2 text-xs font-medium text-slate-100 transition hover:bg-white/10"
        >
          <Copy size={14} />
          {copied ? 'Copied' : 'Copy'}
        </button>
      </div>
    </div>
  );
}

function VideoCard({ title, channel, summary, url }: { title: string; channel: string; summary: string; url: string }) {
  return (
    <a
      href={url}
      className="group rounded-2xl border border-white/10 bg-white/5 p-4 transition hover:border-primary-400/40 hover:bg-white/10"
    >
      <div className="flex items-start justify-between gap-3">
        <div>
          <div className="text-xs uppercase tracking-[0.2em] text-slate-400">{channel}</div>
          <h3 className="mt-2 text-sm font-semibold text-white">{title}</h3>
        </div>
        <PlayCircle className="text-primary-300 transition group-hover:scale-110" size={18} />
      </div>
      <p className="mt-3 text-sm leading-6 text-slate-400">{summary}</p>
    </a>
  );
}

type PaperSection = 'overview' | 'reader' | 'translate' | 'ai' | 'notes';

export default function PaperWorkspace({ paper }: { paper: ScientificPaper }) {
  const { savedPapers, toggleSavePaper, paperNotes, setPaperNote, results } = useAppStore();
  const saved = savedPapers.some((item) => item.id === paper.id);
  const note = paperNotes[paper.id] ?? '';
  const isInResults = results.some((item) => item.id === paper.id);

  const citations = useMemo(() => citationFormats(paper), [paper]);
  const insights = useMemo(() => buildKeyInsights(paper), [paper]);
  const summary = useMemo(() => buildReadingSummary(paper), [paper]);
  const videos = useMemo(() => buildVideoRecommendations(paper.title, [paper]).slice(0, 4), [paper]);

  const [activeSection, setActiveSection] = useState<PaperSection>('overview');
  const [translationTarget, setTranslationTarget] = useState<'ar' | 'en'>('ar');
  const [translationSource, setTranslationSource] = useState<string>('auto');
  const [translationInput, setTranslationInput] = useState(paper.abstract);
  const [translationOutput, setTranslationOutput] = useState('');
  const [translationLoading, setTranslationLoading] = useState(false);
  const [translationEngine, setTranslationEngine] = useState<'mymemory' | 'fallback' | ''>('');
  const [copiedCitation, setCopiedCitation] = useState<'apa' | 'ieee' | 'bibtex' | null>(null);

  async function runTranslation() {
    const text = translationInput.trim();
    if (!text) return;
    setTranslationLoading(true);
    try {
      const response = await translateScientificText({
        text,
        sourceLanguage: translationSource === 'auto' ? undefined : translationSource,
        targetLanguage: translationTarget,
      });
      setTranslationOutput(response.translatedText);
      setTranslationEngine(response.provider);
      if (response.detectedSourceLanguage === 'ar') {
        setTranslationSource('ar');
      } else if (response.detectedSourceLanguage === 'en') {
        setTranslationSource('en');
      }
      setTranslationTarget(response.targetLanguage as 'ar' | 'en');
    } finally {
      setTranslationLoading(false);
    }
  }

  return (
    <div className="min-h-screen bg-[radial-gradient(circle_at_top,_rgba(44,139,255,.22),_transparent_40%),linear-gradient(180deg,#07111f_0%,#0b1527_100%)] text-white">
      <div className="mx-auto flex min-h-screen max-w-7xl flex-col gap-6 px-4 py-4 md:px-6 lg:px-8">
        <header className="rounded-3xl border border-white/10 bg-white/5 p-5 shadow-soft backdrop-blur-xl">
          <div className="flex flex-col gap-5 lg:flex-row lg:items-start lg:justify-between">
            <div className="space-y-4">
              <Link href="/" className="inline-flex items-center gap-2 text-sm text-slate-300 transition hover:text-white">
                <ArrowLeft size={16} />
                Back to search
              </Link>

              <div className="inline-flex items-center gap-2 rounded-full border border-primary-400/20 bg-primary-500/10 px-3 py-1 text-xs font-medium text-primary-100">
                <Sparkles size={14} />
                Research workspace
              </div>

              <h1 className="max-w-5xl text-3xl font-semibold leading-tight text-white md:text-4xl">{paper.title}</h1>

              <div className="flex flex-wrap items-center gap-2 text-sm text-slate-300">
                <span>{authorList(paper.authors, 8)}</span>
                <span>•</span>
                <span>{formatSourceLabel(paper.source)}</span>
                <span>•</span>
                <span>{yearLabel(paper.year)}</span>
                {paper.venue ? (
                  <>
                    <span>•</span>
                    <span>{paper.venue}</span>
                  </>
                ) : null}
              </div>

              <div className="flex flex-wrap gap-2">
                {paper.keywords.slice(0, 8).map((keyword) => (
                  <span key={keyword} className="rounded-full border border-white/10 bg-white/5 px-3 py-1 text-xs text-slate-200">
                    {keyword}
                  </span>
                ))}
              </div>
            </div>

            <div className="grid gap-3 sm:grid-cols-2 lg:w-[420px]">
              <Stat label="Citations" value={paper.citationCount === null ? 'n/a' : String(paper.citationCount)} />
              <Stat label="Access" value={paper.openAccess ? 'Open access' : 'Restricted / unknown'} />
              <Stat label="DOI" value={paper.doi ?? 'n/a'} />
              <Stat label="Library" value={saved ? 'Saved' : 'Not saved'} />
            </div>
          </div>
        </header>

        <section className="rounded-3xl border border-white/10 bg-white/5 p-3 shadow-soft">
          <div className="flex flex-wrap gap-2">
            {([
              ['overview', 'Overview', LayoutGrid],
              ['reader', 'Reader', FileSearch],
              ['translate', 'Translate', Languages],
              ['ai', 'AI Notes', Rocket],
              ['notes', 'Notes', ScrollText],
            ] as const).map(([key, label, Icon]) => (
              <button
                key={key}
                type="button"
                onClick={() => setActiveSection(key)}
                className={`inline-flex flex-1 min-w-[140px] items-center justify-center gap-2 rounded-2xl border px-4 py-3 text-sm font-medium transition ${
                  activeSection === key ? 'border-primary-400 bg-primary-500/10 text-white' : 'border-transparent bg-transparent text-slate-300 hover:bg-white/5'
                }`}
              >
                <Icon size={16} />
                {label}
              </button>
            ))}
          </div>
        </section>

        <section className="grid gap-6 xl:grid-cols-[1.2fr_0.8fr]">
          <div className="space-y-6">
            {activeSection === 'overview' ? (
              <>
                <div className="rounded-3xl border border-white/10 bg-white/5 p-6 shadow-soft">
                  <SectionTitle
                    eyebrow="Overview"
                    title="Reading summary"
                    description="A concise, research-friendly overview to help you decide how this paper fits your current task."
                  />
                  <p className="mt-5 text-[15px] leading-8 text-slate-200">{summary}</p>

                  <div className="mt-6 grid gap-3 sm:grid-cols-2 xl:grid-cols-3">
                    <Stat label="Published" value={paper.publishedDate ?? 'n/a'} />
                    <Stat label="Source URL" value={paper.url} />
                    <Stat label="PDF URL" value={paper.pdfUrl ?? 'n/a'} />
                  </div>

                  <div className="mt-6 flex flex-wrap gap-3">
                    <ActionButton variant="primary" href={safeUrl(paper.url)}>
                      <ExternalLink size={16} />
                      Open source
                    </ActionButton>
                    <ActionButton href={paper.pdfUrl ? safeUrl(paper.pdfUrl) : safeUrl(paper.url)}>
                      <FileText size={16} />
                      PDF / landing page
                    </ActionButton>
                    <Link
                      href={`/translate?text=${encodeURIComponent(paper.abstract)}&title=${encodeURIComponent(paper.title)}`}
                      className="inline-flex items-center gap-2 rounded-2xl border border-white/10 bg-white/5 px-4 py-3 text-sm font-medium text-slate-100 transition hover:bg-white/10"
                    >
                      <ArrowRightLeft size={16} />
                      Translate abstract
                    </Link>
                    <ActionButton onClick={() => toggleSavePaper(paper)}>
                      {saved ? <BookmarkCheck size={16} /> : <Bookmark size={16} />}
                      {saved ? 'Remove from library' : 'Save to library'}
                    </ActionButton>
                  </div>
                </div>

                <div className="rounded-3xl border border-white/10 bg-white/5 p-6 shadow-soft">
                  <SectionTitle
                    eyebrow="Abstract"
                    title="Original abstract"
                    description="This is the exact abstract returned by the scholarly source."
                  />
                  <div className="mt-5 whitespace-pre-line text-[15px] leading-8 text-slate-200">{paper.abstract}</div>
                </div>

                <div className="rounded-3xl border border-white/10 bg-white/5 p-6 shadow-soft">
                  <SectionTitle
                    eyebrow="Key insights"
                    title="Automatic reading hints"
                    description="These are heuristic study hints generated from the title, abstract, and keywords."
                  />
                  <div className="mt-5 grid gap-3">
                    {insights.map((insight) => (
                      <div key={insight} className="rounded-2xl border border-white/10 bg-white/5 p-4 text-sm leading-7 text-slate-200">
                        {insight}
                      </div>
                    ))}
                  </div>
                </div>
              </>
            ) : null}

            {activeSection === 'reader' ? (
              <div className="rounded-3xl border border-white/10 bg-white/5 p-6 shadow-soft">
                <SectionTitle
                  eyebrow="Reader"
                  title="PDF / landing page preview"
                  description="Open the source inside the app and keep the reading workflow in one workspace."
                />
                <div className="mt-5 overflow-hidden rounded-3xl border border-white/10 bg-[#09111f]">
                  {paper.pdfUrl ? (
                    <iframe
                      title={paper.title}
                      src={safeUrl(paper.pdfUrl)}
                      className="h-[700px] w-full"
                      loading="lazy"
                    />
                  ) : (
                    <div className="flex min-h-[420px] flex-col items-center justify-center gap-4 p-6 text-center text-slate-300">
                      <PanelLeft size={28} className="text-slate-500" />
                      <div className="max-w-lg text-sm leading-7">
                        No direct PDF was indexed for this result. Open the landing page or use the translation and notes tools in the other sections.
                      </div>
                    </div>
                  )}
                </div>

                <div className="mt-5 flex flex-wrap gap-3">
                  <ActionButton variant="primary" href={paper.pdfUrl ? safeUrl(paper.pdfUrl) : safeUrl(paper.url)}>
                    <ExternalLink size={16} />
                    Open source
                  </ActionButton>
                  {paper.pdfUrl ? (
                    <a
                      href={safeUrl(paper.pdfUrl)}
                      download
                      className="inline-flex items-center gap-2 rounded-2xl border border-white/10 bg-white/5 px-4 py-3 text-sm font-medium text-slate-100 transition hover:bg-white/10"
                    >
                      <FileText size={16} />
                      Download PDF
                    </a>
                  ) : null}
                  <Link
                    href={`/translate?text=${encodeURIComponent(paper.abstract)}&title=${encodeURIComponent(paper.title)}`}
                    className="inline-flex items-center gap-2 rounded-2xl border border-white/10 bg-white/5 px-4 py-3 text-sm font-medium text-slate-100 transition hover:bg-white/10"
                  >
                    <ArrowRightLeft size={16} />
                    Translate abstract
                  </Link>
                  <ActionButton onClick={() => setActiveSection('translate')}>
                    <ArrowRightLeft size={16} />
                    In workspace
                  </ActionButton>
                </div>
              </div>
            ) : null}

            {activeSection === 'translate' ? (
              <div className="rounded-3xl border border-white/10 bg-white/5 p-6 shadow-soft">
                <SectionTitle
                  eyebrow="Translation"
                  title="Scientific translation"
                  description="Translate the abstract or any selected note text without leaving the paper workspace."
                />
                <div className="mt-5 grid gap-4 xl:grid-cols-2">
                  <div>
                    <div className="mb-2 text-xs uppercase tracking-[0.2em] text-slate-400">Source text</div>
                    <textarea
                      value={translationInput}
                      onChange={(event) => setTranslationInput(event.target.value)}
                      rows={14}
                      className="w-full rounded-2xl border border-white/10 bg-[#0a1220] px-4 py-3 text-sm leading-7 text-slate-100 outline-none placeholder:text-slate-500 focus:border-primary-400/50"
                    />
                  </div>
                  <div className="space-y-4">
                    <div className="grid gap-3 md:grid-cols-2">
                      <label className="space-y-2 text-sm text-slate-300">
                        <span className="text-xs uppercase tracking-[0.2em] text-slate-400">Source language</span>
                        <select
                          value={translationSource}
                          onChange={(event) => setTranslationSource(event.target.value)}
                          className="w-full rounded-2xl border border-white/10 bg-[#0a1220] px-4 py-3 text-white outline-none"
                        >
                          <option value="auto">Auto detect</option>
                          <option value="ar">Arabic</option>
                          <option value="en">English</option>
                        </select>
                      </label>
                      <label className="space-y-2 text-sm text-slate-300">
                        <span className="text-xs uppercase tracking-[0.2em] text-slate-400">Target language</span>
                        <select
                          value={translationTarget}
                          onChange={(event) => setTranslationTarget(event.target.value as 'ar' | 'en')}
                          className="w-full rounded-2xl border border-white/10 bg-[#0a1220] px-4 py-3 text-white outline-none"
                        >
                          <option value="ar">Arabic</option>
                          <option value="en">English</option>
                        </select>
                      </label>
                    </div>

                    <button
                      type="button"
                      onClick={runTranslation}
                      disabled={translationLoading || !translationInput.trim()}
                      className="inline-flex items-center gap-2 rounded-2xl bg-primary-500 px-4 py-3 text-sm font-semibold text-white transition hover:bg-primary-400 disabled:cursor-not-allowed disabled:opacity-70"
                    >
                      {translationLoading ? <Loader2 className="animate-spin" size={16} /> : <Languages size={16} />}
                      Translate
                    </button>

                    <div className="rounded-2xl border border-white/10 bg-[#0a1220] p-4">
                      <div className="mb-3 flex items-center justify-between gap-3">
                        <div className="text-xs uppercase tracking-[0.2em] text-slate-400">Translation output</div>
                        <button
                          type="button"
                          onClick={async () => {
                            if (!translationOutput) return;
                            await navigator.clipboard.writeText(translationOutput);
                          }}
                          className="inline-flex items-center gap-2 rounded-xl border border-white/10 bg-white/5 px-3 py-2 text-xs font-medium text-slate-100 transition hover:bg-white/10"
                        >
                          <Copy size={14} />
                          Copy
                        </button>
                      </div>
                      <div className="whitespace-pre-line text-sm leading-7 text-slate-200">
                        {translationOutput || 'Your translation will appear here.'}
                      </div>
                    </div>

                    <div className="rounded-2xl border border-white/10 bg-white/5 p-4 text-sm leading-7 text-slate-300">
                      Translation engine: {translationEngine || 'ready'}.
                    </div>
                  </div>
                </div>
              </div>
            ) : null}

            {activeSection === 'ai' ? (
              <div className="rounded-3xl border border-white/10 bg-white/5 p-6 shadow-soft">
                <SectionTitle
                  eyebrow="AI notes"
                  title="AI-ready scientific assistance"
                  description="This workspace is prepared for later large-language-model integration."
                />
                <div className="mt-5 grid gap-3">
                  {insights.map((insight) => (
                    <div key={insight} className="rounded-2xl border border-white/10 bg-white/5 p-4 text-sm leading-7 text-slate-200">
                      {insight}
                    </div>
                  ))}
                  <div className="rounded-2xl border border-primary-400/20 bg-primary-500/10 p-4 text-sm leading-7 text-slate-100">
                    Future AI actions: summarise, compare papers, explain methods, generate study questions, and draft literature-review notes.
                  </div>
                </div>
              </div>
            ) : null}

            {activeSection === 'notes' ? (
              <>
                <div className="rounded-3xl border border-white/10 bg-white/5 p-6 shadow-soft">
                  <SectionTitle
                    eyebrow="Notes"
                    title="Personal paper notes"
                    description="Saved locally in the browser so you can keep reading notes with the paper."
                  />
                  <textarea
                    value={note}
                    onChange={(event) => setPaperNote(paper.id, event.target.value)}
                    rows={10}
                    placeholder="Write your notes, questions, or summary here..."
                    className="mt-5 w-full rounded-2xl border border-white/10 bg-[#0a1220] px-4 py-3 text-sm leading-7 text-slate-100 outline-none placeholder:text-slate-500 focus:border-primary-400/50"
                  />
                  <div className="mt-3 text-xs text-slate-400">
                    {isInResults
                      ? 'This paper is part of the current search results.'
                      : 'This paper was opened directly and can still be saved in the library.'}
                  </div>
                </div>

                <div className="rounded-3xl border border-white/10 bg-white/5 p-6 shadow-soft">
                  <SectionTitle
                    eyebrow="Citation export"
                    title="Ready-to-copy citations"
                    description="Use these formats in manuscripts, notes, and literature reviews."
                  />
                  <div className="mt-5 grid gap-5">
                    {(['apa', 'ieee', 'bibtex'] as const).map((type) => (
                      <div key={type}>
                        <div className="mb-3 text-xs uppercase tracking-[0.2em] text-slate-400">{type.toUpperCase()}</div>
                        <CodeBlock value={citations[type]} />
                        <div className="mt-3 flex justify-end">
                          <button
                            type="button"
                            onClick={async () => {
                              await navigator.clipboard.writeText(citations[type]);
                              setCopiedCitation(type);
                              window.setTimeout(() => setCopiedCitation((current) => (current === type ? null : current)), 1200);
                            }}
                            className="inline-flex items-center gap-2 rounded-xl border border-white/10 bg-white/5 px-3 py-2 text-xs font-medium text-slate-100 transition hover:bg-white/10"
                          >
                            <Copy size={14} />
                            {copiedCitation === type ? 'Copied' : 'Copy citation'}
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </>
            ) : null}
          </div>

          <aside className="space-y-6">
            <div className="rounded-3xl border border-white/10 bg-white/5 p-6 shadow-soft">
              <SectionTitle
                eyebrow="Study actions"
                title="Research controls"
                description="The UI is ready for future AI translation, annotation, and PDF extraction features."
              />
              <div className="mt-5 grid gap-3">
                <ActionButton href={paper.pdfUrl ? safeUrl(paper.pdfUrl) : safeUrl(paper.url)}>
                  <FileText size={16} />
                  Open reading source
                </ActionButton>
                <ActionButton onClick={() => toggleSavePaper(paper)}>
                  {saved ? <BookmarkCheck size={16} /> : <Bookmark size={16} />}
                  {saved ? 'In library' : 'Add to library'}
                </ActionButton>
                <ActionButton href={safeUrl(paper.doi ? `https://doi.org/${paper.doi}` : paper.url)}>
                  <ExternalLink size={16} />
                  Open DOI / source page
                </ActionButton>
              </div>
            </div>

            <div className="rounded-3xl border border-white/10 bg-white/5 p-6 shadow-soft">
              <SectionTitle
                eyebrow="Related videos"
                title="Trusted scientific video search"
                description="These are source-specific search shortcuts to educational video results around the same topic."
              />
              <div className="mt-5 grid gap-3">
                {videos.map((video) => (
                  <VideoCard key={video.id} {...video} />
                ))}
              </div>
            </div>

            <div className="rounded-3xl border border-white/10 bg-white/5 p-6 shadow-soft">
              <SectionTitle
                eyebrow="Library"
                title="Local reading status"
                description="Use the library in the main application to collect papers and keep working on them."
              />
              <div className="mt-5 grid gap-3">
                <div className="rounded-2xl border border-white/10 bg-white/5 p-4 text-sm text-slate-200">
                  Saved papers are stored in browser local storage and restored on the next visit.
                </div>
                <div className="rounded-2xl border border-white/10 bg-white/5 p-4 text-sm text-slate-200">
                  Notes and bookmarks are tied to this paper id, so the workspace remains usable across sessions.
                </div>
              </div>
            </div>
          </aside>
        </section>
      </div>
    </div>
  );
}
