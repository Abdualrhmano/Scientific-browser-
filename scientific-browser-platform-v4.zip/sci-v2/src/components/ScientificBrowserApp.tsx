'use client';

import React, { useEffect, useMemo } from 'react';
import Link from 'next/link';
import {
  ArrowRight,
  BookOpen,
  Bookmark,
  BookmarkCheck,
  ChevronRight,
  ExternalLink,
  FileText,
  Flame,
  Globe2,
  History,
  Loader2,
  Moon,
  PlayCircle,
  Search,
  Sun,
  X,
} from 'lucide-react';
import { useAppStore } from '@/store/useAppStore';
import { authorList, formatSourceLabel, safeUrl, truncateText, yearLabel } from '@/lib/format';
import type { ScientificPaper, ScientificVideo } from '@/lib/types';
import { encodePaperSlug } from '@/lib/paperRoute';
import { citationFormats } from '@/lib/citations';
import { buildKeyInsights, buildReadingSummary } from '@/lib/insights';

function Stat({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-2xl border border-white/10 bg-white/5 px-4 py-3 backdrop-blur">
      <div className="text-[11px] uppercase tracking-[0.22em] text-slate-400">{label}</div>
      <div className="mt-1 break-words text-base font-semibold text-white">{value}</div>
    </div>
  );
}

function SourceBadge({ source }: { source: ScientificPaper['source'] }) {
  return (
    <span className="inline-flex items-center rounded-full border border-primary-400/30 bg-primary-400/10 px-2.5 py-1 text-[11px] font-medium text-primary-200">
      {formatSourceLabel(source)}
    </span>
  );
}

function VideoCard({ video }: { video: ScientificVideo }) {
  return (
    <a
      href={video.url}
      target="_blank"
      rel="noreferrer"
      className="group flex flex-col gap-3 rounded-2xl border border-white/10 bg-white/5 p-4 transition hover:border-primary-400/40 hover:bg-white/10"
    >
      <div className="flex items-start justify-between gap-3">
        <div>
          <div className="text-[11px] uppercase tracking-[0.2em] text-slate-400">Video source</div>
          <h4 className="mt-1 text-sm font-semibold text-white">{video.channel}</h4>
        </div>
        <PlayCircle className="text-primary-300 transition group-hover:scale-110" size={18} />
      </div>
      <div className="text-sm text-slate-200">{video.title}</div>
      <p className="text-sm leading-6 text-slate-400">{video.summary}</p>
      <div className="text-xs text-primary-200">Open video workspace</div>
    </a>
  );
}

function PaperCard({
  paper,
  active,
  onClick,
  onSave,
  saved,
}: {
  paper: ScientificPaper;
  active: boolean;
  onClick: () => void;
  onSave: () => void;
  saved: boolean;
}) {
  const paperHref = `/paper/${encodePaperSlug(paper)}`;

  return (
    <article
      onClick={onClick}
      className={`cursor-pointer rounded-2xl border p-4 transition ${
        active ? 'border-primary-400 bg-primary-500/10 shadow-soft' : 'border-white/10 bg-white/5 hover:border-white/20 hover:bg-white/10'
      }`}
    >
      <div className="flex items-start justify-between gap-3">
        <div className="space-y-2">
          <SourceBadge source={paper.source} />
          <h3 className="line-clamp-2 text-base font-semibold text-white">{paper.title}</h3>
        </div>
        <button
          type="button"
          onClick={(e) => {
            e.stopPropagation();
            onSave();
          }}
          className="rounded-xl border border-white/10 p-2 text-slate-200 transition hover:border-primary-400/40 hover:bg-white/10"
          aria-label={saved ? 'Remove from library' : 'Save to library'}
        >
          {saved ? <BookmarkCheck size={16} /> : <Bookmark size={16} />}
        </button>
      </div>

      <div className="mt-3 flex flex-wrap items-center gap-2 text-xs text-slate-400">
        <span>{yearLabel(paper.year)}</span>
        <span>•</span>
        <span>{authorList(paper.authors)}</span>
      </div>

      <p className="mt-3 line-clamp-3 text-sm leading-6 text-slate-300">{truncateText(paper.abstract, 220)}</p>

      <div className="mt-4 flex flex-wrap items-center gap-2 text-xs text-slate-400">
        {paper.citationCount !== null ? <span className="rounded-full bg-white/5 px-2 py-1">Citations: {paper.citationCount}</span> : null}
        {paper.openAccess ? (
          <span className="rounded-full bg-emerald-500/10 px-2 py-1 text-emerald-200">Open access</span>
        ) : (
          <span className="rounded-full bg-amber-500/10 px-2 py-1 text-amber-200">Closed / unknown</span>
        )}
      </div>

      <div className="mt-4 flex flex-wrap items-center justify-between gap-3">
        <Link href={paperHref} onClick={(e) => e.stopPropagation()} className="inline-flex items-center gap-2 text-xs font-medium text-primary-200 transition hover:text-white">
          Open details
          <ArrowRight size={14} />
        </Link>

        <Link
          href={`/translate?text=${encodeURIComponent(paper.abstract)}&title=${encodeURIComponent(paper.title)}`}
          onClick={(e) => e.stopPropagation()}
          className="inline-flex items-center gap-2 text-xs font-medium text-slate-300 transition hover:text-white"
        >
          Translate abstract
          <ChevronRight size={12} />
        </Link>

        <a
          href={safeUrl(paper.doi ? `https://doi.org/${paper.doi}` : paper.url)}
          target="_blank"
          rel="noreferrer"
          onClick={(e) => e.stopPropagation()}
          className="inline-flex items-center gap-1 text-xs text-slate-400 transition hover:text-slate-100"
        >
          DOI / source
          <ExternalLink size={12} />
        </a>
      </div>
    </article>
  );
}

function DetailPanel({ paper, onSave, saved }: { paper: ScientificPaper; onSave: () => void; saved: boolean }) {
  const summary = useMemo(() => buildReadingSummary(paper), [paper]);
  const insights = useMemo(() => buildKeyInsights(paper), [paper]);
  const citations = useMemo(() => citationFormats(paper), [paper]);
  const [copied, setCopied] = React.useState<'apa' | 'ieee' | 'bibtex' | null>(null);

  return (
    <div className="rounded-3xl border border-white/10 bg-white/5 p-6 shadow-soft">
      <div className="flex items-start justify-between gap-4">
        <div>
          <SourceBadge source={paper.source} />
          <h2 className="mt-3 text-2xl font-semibold leading-tight text-white">{paper.title}</h2>
          <p className="mt-3 text-sm leading-7 text-slate-300">{authorList(paper.authors, 8)}</p>
        </div>
        <div className="rounded-2xl border border-primary-400/20 bg-primary-500/10 p-3 text-primary-100">
          <FileText size={22} />
        </div>
      </div>

      <p className="mt-5 text-[15px] leading-8 text-slate-200">{summary}</p>

      <div className="mt-5 grid gap-3 sm:grid-cols-2 xl:grid-cols-3">
        <Stat label="Year" value={yearLabel(paper.year)} />
        <Stat label="Venue" value={paper.venue || 'n/a'} />
        <Stat label="DOI" value={paper.doi || 'n/a'} />
      </div>

      <div className="mt-6 space-y-3">
        <h3 className="text-sm font-semibold uppercase tracking-[0.2em] text-slate-400">Abstract</h3>
        <p className="whitespace-pre-line text-[15px] leading-7 text-slate-200">{paper.abstract}</p>
      </div>

      {paper.keywords.length ? (
        <div className="mt-6 space-y-3">
          <h3 className="text-sm font-semibold uppercase tracking-[0.2em] text-slate-400">Keywords</h3>
          <div className="flex flex-wrap gap-2">
            {paper.keywords.map((keyword) => (
              <span key={keyword} className="rounded-full border border-white/10 bg-white/5 px-3 py-1 text-sm text-slate-200">
                {keyword}
              </span>
            ))}
          </div>
        </div>
      ) : null}

      <div className="mt-6 grid gap-3 sm:grid-cols-2 xl:grid-cols-3">
        <a href={safeUrl(paper.url)} target="_blank" rel="noreferrer" className="inline-flex items-center justify-center gap-2 rounded-2xl bg-primary-500 px-4 py-3 text-sm font-semibold text-white transition hover:bg-primary-400">
          Open source <ExternalLink size={16} />
        </a>
        <a href={paper.pdfUrl ? safeUrl(paper.pdfUrl) : safeUrl(paper.url)} target="_blank" rel="noreferrer" className="inline-flex items-center justify-center gap-2 rounded-2xl border border-white/10 bg-white/5 px-4 py-3 text-sm font-semibold text-slate-100 transition hover:bg-white/10">
          PDF / landing page <ChevronRight size={16} />
        </a>
        <Link href={`/translate?text=${encodeURIComponent(paper.abstract)}&title=${encodeURIComponent(paper.title)}`} className="inline-flex items-center justify-center gap-2 rounded-2xl border border-white/10 bg-white/5 px-4 py-3 text-sm font-semibold text-slate-100 transition hover:bg-white/10">
          Translate abstract <ChevronRight size={16} />
        </Link>
      </div>

      <div className="mt-6 flex flex-wrap gap-3">
        <button
          type="button"
          onClick={onSave}
          className="inline-flex items-center gap-2 rounded-2xl border border-white/10 bg-white/5 px-4 py-3 text-sm font-medium text-slate-100 transition hover:bg-white/10"
        >
          {saved ? <BookmarkCheck size={16} /> : <Bookmark size={16} />}
          {saved ? 'Remove from library' : 'Save to library'}
        </button>
        <Link href={`/paper/${encodePaperSlug(paper)}`} className="inline-flex items-center gap-2 rounded-2xl border border-white/10 bg-white/5 px-4 py-3 text-sm font-medium text-slate-100 transition hover:bg-white/10">
          <FileText size={16} />
          Open details page
        </Link>
      </div>

      <div className="mt-6 grid gap-3">
        <h3 className="text-sm font-semibold uppercase tracking-[0.2em] text-slate-400">Reading hints</h3>
        {insights.map((insight) => (
          <div key={insight} className="rounded-2xl border border-white/10 bg-white/5 p-4 text-sm leading-7 text-slate-200">
            {insight}
          </div>
        ))}
      </div>

      <div className="mt-6 space-y-3">
        <h3 className="text-sm font-semibold uppercase tracking-[0.2em] text-slate-400">Citation export</h3>
        {(['apa', 'ieee', 'bibtex'] as const).map((type) => (
          <div key={type} className="rounded-2xl border border-white/10 bg-[#0a1220] p-4">
            <div className="mb-2 flex items-center justify-between gap-3">
              <div className="text-xs uppercase tracking-[0.2em] text-slate-400">{type}</div>
              <button
                type="button"
                onClick={async () => {
                  await navigator.clipboard.writeText(citations[type]);
                  setCopied(type);
                  window.setTimeout(() => setCopied(null), 1300);
                }}
                className="inline-flex items-center gap-2 rounded-xl border border-white/10 bg-white/5 px-3 py-1.5 text-xs font-medium text-slate-100 transition hover:bg-white/10"
              >
                <ChevronRight size={13} />
                {copied === type ? 'Copied' : 'Copy'}
              </button>
            </div>
            <pre className="whitespace-pre-wrap break-words text-sm leading-7 text-slate-200">{citations[type]}</pre>
          </div>
        ))}
      </div>
    </div>
  );
}

export default function ScientificBrowserApp() {
  const {
    filters,
    setFilters,
    performSearch,
    results,
    videos,
    selectedPaper,
    selectPaper,
    toggleSavePaper,
    savedPapers,
    queryHistory,
    clearHistory,
    darkMode,
    setDarkMode,
    isSearching,
    errors,
    removeSavedPaper,
  } = useAppStore();

  useEffect(() => {
    document.documentElement.classList.toggle('dark', darkMode);
  }, [darkMode]);

  useEffect(() => {
    const onKeyDown = (event: KeyboardEvent) => {
      if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === 'k') {
        event.preventDefault();
        document.getElementById('scientific-search-input')?.focus();
      }
      if (event.key === 'Escape') {
        selectPaper(null);
      }
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [selectPaper]);

  useEffect(() => {
    if (!results.length) return;
    if (!selectedPaper || !results.some((paper) => paper.id === selectedPaper.id)) {
      selectPaper(results[0]);
    }
  }, [results, selectedPaper, selectPaper]);

  const hasResults = results.length > 0;
  const savedIds = useMemo(() => new Set(savedPapers.map((paper) => paper.id)), [savedPapers]);

  return (
    <div className="min-h-screen bg-[radial-gradient(circle_at_top,_rgba(44,139,255,.24),_transparent_38%),linear-gradient(180deg,#07111f_0%,#0b1527_100%)] text-white">
      <div className="mx-auto flex min-h-screen max-w-[1600px] flex-col gap-6 px-4 py-4 md:px-6 lg:px-8">
        <header className="rounded-3xl border border-white/10 bg-white/5 p-5 shadow-soft backdrop-blur-xl">
          <div className="flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
            <div className="space-y-2">
              <div className="inline-flex items-center gap-2 rounded-full border border-primary-400/20 bg-primary-500/10 px-3 py-1 text-xs font-medium text-primary-100">
                <Globe2 size={14} /> Scientific research platform
              </div>
              <h1 className="text-2xl font-semibold md:text-3xl">Scientific Browser</h1>
              <p className="max-w-3xl text-sm leading-7 text-slate-300">
                Search scholarly sources, inspect papers before opening them, build a reading library, and jump to related scientific video search results.
              </p>
            </div>

            <div className="grid gap-3 sm:grid-cols-3 lg:w-[560px]">
              <Stat label="Results" value={String(results.length)} />
              <Stat label="Saved" value={String(savedPapers.length)} />
              <Stat label="Mode" value={darkMode ? 'Dark' : 'Light'} />
            </div>
          </div>
        </header>

        <section className="grid gap-3 md:grid-cols-2 xl:grid-cols-4">
          <a href="/library" className="rounded-3xl border border-white/10 bg-white/5 p-5 shadow-soft transition hover:border-primary-400/40 hover:bg-white/10">
            <div className="text-xs uppercase tracking-[0.2em] text-slate-400">Platform</div>
            <div className="mt-2 text-lg font-semibold text-white">Scientific Library</div>
            <p className="mt-2 text-sm leading-6 text-slate-400">Collect papers, notes, and saved reading lists.</p>
          </a>
          <a href="/videos" className="rounded-3xl border border-white/10 bg-white/5 p-5 shadow-soft transition hover:border-primary-400/40 hover:bg-white/10">
            <div className="text-xs uppercase tracking-[0.2em] text-slate-400">Media</div>
            <div className="mt-2 text-lg font-semibold text-white">Video workspace</div>
            <p className="mt-2 text-sm leading-6 text-slate-400">Watch trusted scientific learning resources inside the app.</p>
          </a>
          <a href="/translate" className="rounded-3xl border border-white/10 bg-white/5 p-5 shadow-soft transition hover:border-primary-400/40 hover:bg-white/10">
            <div className="text-xs uppercase tracking-[0.2em] text-slate-400">Language</div>
            <div className="mt-2 text-lg font-semibold text-white">Translation lab</div>
            <p className="mt-2 text-sm leading-6 text-slate-400">Translate abstracts and notes without leaving the platform.</p>
          </a>
          <a href="/education" className="rounded-3xl border border-white/10 bg-white/5 p-5 shadow-soft transition hover:border-primary-400/40 hover:bg-white/10">
            <div className="text-xs uppercase tracking-[0.2em] text-slate-400">Learning</div>
            <div className="mt-2 text-lg font-semibold text-white">Education hub</div>
            <p className="mt-2 text-sm leading-6 text-slate-400">Browse global learning pathways and scientific resources.</p>
          </a>
        </section>

        <section className="grid gap-4 xl:grid-cols-[1.25fr_0.75fr]">
          <div className="rounded-3xl border border-white/10 bg-white/5 p-5 shadow-soft backdrop-blur-xl">
            <div className="flex flex-col gap-4">
              <div className="flex items-center gap-3">
                <div className="relative flex-1">
                  <Search className="pointer-events-none absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
                  <input
                    id="scientific-search-input"
                    value={filters.query}
                    onChange={(e) => setFilters({ query: e.target.value })}
                    onKeyDown={(e) => {
                      if (e.key === 'Enter') performSearch();
                    }}
                    placeholder="Search papers, DOI, topics, authors…"
                    className="w-full rounded-2xl border border-white/10 bg-[#0a1220] py-3 pl-11 pr-4 text-white outline-none placeholder:text-slate-500 focus:border-primary-400/50"
                  />
                </div>
                <button
                  type="button"
                  onClick={performSearch}
                  disabled={isSearching}
                  className="inline-flex items-center gap-2 rounded-2xl bg-primary-500 px-5 py-3 text-sm font-semibold text-white transition hover:bg-primary-400 disabled:cursor-not-allowed disabled:opacity-70"
                >
                  {isSearching ? <Loader2 className="animate-spin" size={16} /> : <Search size={16} />}
                  Search
                </button>
              </div>

              <div className="grid gap-3 md:grid-cols-2 xl:grid-cols-5">
                <label className="space-y-2 text-sm text-slate-300">
                  <span className="text-xs uppercase tracking-[0.2em] text-slate-400">Source</span>
                  <select
                    value={filters.source}
                    onChange={(e) => setFilters({ source: e.target.value as typeof filters.source })}
                    className="w-full rounded-2xl border border-white/10 bg-[#0a1220] px-4 py-3 text-white outline-none"
                  >
                    <option value="all">All sources</option>
                    <option value="openalex">OpenAlex</option>
                    <option value="crossref">Crossref</option>
                    <option value="arxiv">arXiv</option>
                    <option value="pubmed">PubMed</option>
                  </select>
                </label>
                <label className="space-y-2 text-sm text-slate-300">
                  <span className="text-xs uppercase tracking-[0.2em] text-slate-400">From</span>
                  <input
                    value={filters.yearFrom}
                    onChange={(e) => setFilters({ yearFrom: e.target.value })}
                    placeholder="2018"
                    className="w-full rounded-2xl border border-white/10 bg-[#0a1220] px-4 py-3 text-white outline-none placeholder:text-slate-500"
                  />
                </label>
                <label className="space-y-2 text-sm text-slate-300">
                  <span className="text-xs uppercase tracking-[0.2em] text-slate-400">To</span>
                  <input
                    value={filters.yearTo}
                    onChange={(e) => setFilters({ yearTo: e.target.value })}
                    placeholder="2025"
                    className="w-full rounded-2xl border border-white/10 bg-[#0a1220] px-4 py-3 text-white outline-none placeholder:text-slate-500"
                  />
                </label>
                <label className="space-y-2 text-sm text-slate-300">
                  <span className="text-xs uppercase tracking-[0.2em] text-slate-400">Sort</span>
                  <select
                    value={filters.sortBy}
                    onChange={(e) => setFilters({ sortBy: e.target.value as typeof filters.sortBy })}
                    className="w-full rounded-2xl border border-white/10 bg-[#0a1220] px-4 py-3 text-white outline-none"
                  >
                    <option value="relevance">Relevance</option>
                    <option value="citations">Citations</option>
                    <option value="recent">Recent</option>
                  </select>
                </label>
                <label className="flex items-center gap-3 rounded-2xl border border-white/10 bg-[#0a1220] px-4 py-3 text-sm text-slate-200">
                  <input
                    type="checkbox"
                    checked={filters.openAccessOnly}
                    onChange={(e) => setFilters({ openAccessOnly: e.target.checked })}
                  />
                  Open access only
                </label>
              </div>

              <div className="flex flex-wrap items-center gap-3">
                <button
                  type="button"
                  onClick={() => setDarkMode(!darkMode)}
                  className="inline-flex items-center gap-2 rounded-2xl border border-white/10 bg-white/5 px-4 py-3 text-sm font-medium text-slate-100 transition hover:bg-white/10"
                >
                  {darkMode ? <Sun size={16} /> : <Moon size={16} />}
                  {darkMode ? 'Light mode' : 'Dark mode'}
                </button>
                {queryHistory.length ? (
                  <button
                    type="button"
                    onClick={clearHistory}
                    className="inline-flex items-center gap-2 rounded-2xl border border-white/10 bg-white/5 px-4 py-3 text-sm font-medium text-slate-100 transition hover:bg-white/10"
                  >
                    <History size={16} /> Clear history
                  </button>
                ) : null}
                <div className="flex flex-wrap gap-2">
                  {queryHistory.map((item) => (
                    <button
                      key={item}
                      type="button"
                      onClick={() => setFilters({ query: item })}
                      className="rounded-full border border-white/10 bg-white/5 px-3 py-1.5 text-xs text-slate-200 transition hover:border-primary-400/40 hover:bg-white/10"
                    >
                      {item}
                    </button>
                  ))}
                </div>
              </div>

              {errors.length ? (
                <div className="rounded-2xl border border-amber-500/20 bg-amber-500/10 p-4 text-sm text-amber-100">
                  <div className="mb-2 font-semibold">Some sources failed</div>
                  <ul className="list-disc space-y-1 pl-5 text-amber-50/90">
                    {errors.map((error) => (
                      <li key={error}>{error}</li>
                    ))}
                  </ul>
                </div>
              ) : null}
            </div>
          </div>

          <div className="rounded-3xl border border-white/10 bg-white/5 p-5 shadow-soft backdrop-blur-xl">
            <div className="flex items-center justify-between">
              <div>
                <div className="text-xs uppercase tracking-[0.2em] text-slate-400">Live sources</div>
                <h2 className="mt-1 text-lg font-semibold text-white">Scientific focus only</h2>
              </div>
              <div className="rounded-2xl border border-white/10 bg-white/5 p-3 text-primary-200">
                <Flame size={18} />
              </div>
            </div>

            <div className="mt-4 grid gap-3 sm:grid-cols-2 xl:grid-cols-1">
              <div className="rounded-2xl border border-white/10 bg-[#0a1220] p-4">
                <div className="text-sm font-semibold text-white">Papers from live APIs</div>
                <p className="mt-2 text-sm leading-6 text-slate-400">
                  OpenAlex, Crossref, arXiv, and PubMed are queried and normalized into one search experience.
                </p>
              </div>
              <div className="rounded-2xl border border-white/10 bg-[#0a1220] p-4">
                <div className="text-sm font-semibold text-white">Preview before opening</div>
                <p className="mt-2 text-sm leading-6 text-slate-400">
                  Inspect the abstract, metadata, citation formats, and scientific hints before jumping to the source.
                </p>
              </div>
            </div>
          </div>
        </section>

        <section className="grid gap-6 xl:grid-cols-[1.15fr_0.85fr]">
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2 text-sm text-slate-400">
                <BookOpen size={16} />
                <span>{hasResults ? `${results.length} results` : 'No results yet'}</span>
              </div>
              <div className="text-sm text-slate-400">
                Press <kbd className="rounded border border-white/10 bg-white/5 px-2 py-1 text-xs text-slate-200">Ctrl</kbd> +{' '}
                <kbd className="rounded border border-white/10 bg-white/5 px-2 py-1 text-xs text-slate-200">K</kbd> to focus search.
              </div>
            </div>

            <div className="grid gap-4 lg:grid-cols-2">
              {results.map((paper) => (
                <PaperCard
                  key={paper.id}
                  paper={paper}
                  active={selectedPaper?.id === paper.id}
                  onClick={() => selectPaper(paper)}
                  onSave={() => toggleSavePaper(paper)}
                  saved={savedIds.has(paper.id)}
                />
              ))}
            </div>
          </div>

          <aside className="space-y-6">
            {selectedPaper ? (
              <DetailPanel paper={selectedPaper} onSave={() => toggleSavePaper(selectedPaper)} saved={savedIds.has(selectedPaper.id)} />
            ) : (
              <div className="rounded-3xl border border-white/10 bg-white/5 p-6 text-slate-300 shadow-soft">
                Run a search to inspect a paper in detail.
              </div>
            )}

            <div className="rounded-3xl border border-white/10 bg-white/5 p-6 shadow-soft">
              <div className="flex items-center justify-between">
                <div>
                  <div className="text-xs uppercase tracking-[0.2em] text-slate-400">Videos</div>
                  <h3 className="mt-1 text-lg font-semibold text-white">Scientific learning videos</h3>
                </div>
                <PlayCircle className="text-primary-300" size={18} />
              </div>
              <div className="mt-4 grid gap-3">
                {videos.slice(0, 4).map((video) => (
                  <VideoCard key={video.id} video={video} />
                ))}
              </div>
            </div>

            <div className="rounded-3xl border border-white/10 bg-white/5 p-6 shadow-soft">
              <div className="flex items-center justify-between">
                <div>
                  <div className="text-xs uppercase tracking-[0.2em] text-slate-400">Library</div>
                  <h3 className="mt-1 text-lg font-semibold text-white">Saved papers</h3>
                </div>
                <BookmarkCheck className="text-primary-300" size={18} />
              </div>
              <div className="mt-4 space-y-3">
                {savedPapers.length ? (
                  savedPapers.map((paper) => (
                    <div key={paper.id} className="rounded-2xl border border-white/10 bg-[#0a1220] p-4">
                      <div className="flex items-start justify-between gap-3">
                        <div>
                          <div className="line-clamp-2 text-sm font-medium text-white">{paper.title}</div>
                          <div className="mt-1 text-xs text-slate-400">
                            {formatSourceLabel(paper.source)} • {yearLabel(paper.year)}
                          </div>
                        </div>
                        <button
                          type="button"
                          onClick={() => removeSavedPaper(paper.id)}
                          className="rounded-xl border border-white/10 p-2 text-slate-300 transition hover:bg-white/10"
                        >
                          <X size={14} />
                        </button>
                      </div>
                      <div className="mt-4 flex items-center justify-between gap-3">
                        <Link href={`/paper/${encodePaperSlug(paper)}`} className="text-xs font-medium text-primary-200 transition hover:text-white">
                          Open details
                        </Link>
                        <span className="text-xs text-slate-500">{authorList(paper.authors, 2)}</span>
                      </div>
                    </div>
                  ))
                ) : (
                  <div className="rounded-2xl border border-dashed border-white/10 bg-[#0a1220]/70 p-4 text-sm text-slate-400">
                    Save papers from the results list to build your personal scientific library.
                  </div>
                )}
              </div>
            </div>
          </aside>
        </section>
      </div>
    </div>
  );
}
