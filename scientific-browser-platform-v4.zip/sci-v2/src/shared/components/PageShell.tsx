import type { ReactNode } from 'react';
import Link from 'next/link';
import { GraduationCap, Languages, LibraryBig, Search, Sparkles, Video } from 'lucide-react';

const quickLinks = [
  { href: '/', label: 'Search', icon: Search },
  { href: '/library', label: 'Library', icon: LibraryBig },
  { href: '/videos', label: 'Videos', icon: Video },
  { href: '/translate', label: 'Translate', icon: Languages },
  { href: '/education', label: 'Education', icon: GraduationCap },
];

export function PageShell({
  title,
  description,
  eyebrow = 'Scientific Browser',
  children,
  action,
}: {
  title: string;
  description: string;
  eyebrow?: string;
  children: ReactNode;
  action?: ReactNode;
}) {
  return (
    <div className="min-h-screen bg-[radial-gradient(circle_at_top,_rgba(44,139,255,.22),_transparent_38%),linear-gradient(180deg,#07111f_0%,#0b1527_100%)] text-white">
      <div className="mx-auto flex min-h-screen max-w-[1600px] flex-col gap-6 px-4 py-4 md:px-6 lg:px-8">
        <header className="rounded-3xl border border-white/10 bg-white/5 p-5 shadow-soft backdrop-blur-xl">
          <div className="flex flex-col gap-5 xl:flex-row xl:items-end xl:justify-between">
            <div className="space-y-4">
              <div className="inline-flex items-center gap-2 rounded-full border border-primary-400/20 bg-primary-500/10 px-3 py-1 text-xs font-medium text-primary-100">
                <Sparkles size={14} />
                {eyebrow}
              </div>
              <div className="space-y-2">
                <h1 className="text-3xl font-semibold tracking-tight md:text-4xl">{title}</h1>
                <p className="max-w-4xl text-sm leading-7 text-slate-300">{description}</p>
              </div>
              <nav className="flex flex-wrap gap-2">
                {quickLinks.map((item) => {
                  const Icon = item.icon;
                  return (
                    <Link
                      key={item.href}
                      href={item.href}
                      className="inline-flex items-center gap-2 rounded-full border border-white/10 bg-white/5 px-3 py-2 text-xs font-medium text-slate-200 transition hover:border-primary-400/40 hover:bg-white/10"
                    >
                      <Icon size={14} />
                      {item.label}
                    </Link>
                  );
                })}
              </nav>
            </div>

            {action ? <div>{action}</div> : null}
          </div>
        </header>

        <main className="pb-6">{children}</main>
      </div>
    </div>
  );
}

export function MetricCard({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-2xl border border-white/10 bg-white/5 px-4 py-3 backdrop-blur">
      <div className="text-[11px] uppercase tracking-[0.22em] text-slate-400">{label}</div>
      <div className="mt-1 break-words text-base font-semibold text-white">{value}</div>
    </div>
  );
}

export function SectionHeading({
  eyebrow,
  title,
  description,
}: {
  eyebrow: string;
  title: string;
  description?: string;
}) {
  return (
    <div className="space-y-2">
      <div className="text-xs font-medium uppercase tracking-[0.22em] text-slate-400">{eyebrow}</div>
      <h2 className="text-2xl font-semibold text-white">{title}</h2>
      {description ? <p className="max-w-3xl text-sm leading-7 text-slate-400">{description}</p> : null}
    </div>
  );
}

export function InlinePill({ children }: { children: ReactNode }) {
  return (
    <span className="inline-flex items-center rounded-full border border-white/10 bg-white/5 px-3 py-1 text-xs text-slate-200">
      {children}
    </span>
  );
}
