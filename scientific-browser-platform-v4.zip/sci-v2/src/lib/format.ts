import type { ScientificAuthor } from './types';

export function authorList(authors: ScientificAuthor[], max = 3): string {
  if (!authors.length) return 'Unknown author';
  const names = authors.slice(0, max).map((a) => a.name);
  const suffix = authors.length > max ? ` +${authors.length - max}` : '';
  return `${names.join(', ')}${suffix}`;
}

export function yearLabel(year: number | null): string {
  return year ? String(year) : 'n/a';
}

export function truncateText(text: string, max = 220): string {
  if (text.length <= max) return text;
  return `${text.slice(0, max).trim()}…`;
}

export function formatSourceLabel(source: string): string {
  switch (source) {
    case 'openalex':
      return 'OpenAlex';
    case 'crossref':
      return 'Crossref';
    case 'arxiv':
      return 'arXiv';
    case 'pubmed':
      return 'PubMed';
    default:
      return source;
  }
}

export function safeUrl(input: string | null | undefined): string {
  if (!input) return '#';
  return input;
}
