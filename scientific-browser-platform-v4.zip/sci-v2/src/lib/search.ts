import type { SearchFilters, ScientificPaper, ScientificSource, ScientificVideo } from './types';
import {
  normalizeCrossref,
  normalizeOpenAlex,
  normalizePubMed,
} from './normalizers';
import { buildVideoRecommendations } from './videos';

const DEFAULT_LIMIT = 10;

function clampLimit(limit: number): number {
  if (!Number.isFinite(limit)) return DEFAULT_LIMIT;
  return Math.min(Math.max(Math.trunc(limit), 1), 20);
}

function dedupePapers(papers: ScientificPaper[]): ScientificPaper[] {
  const seen = new Set<string>();
  const out: ScientificPaper[] = [];
  for (const paper of papers) {
    const key = [
      paper.doi?.toLowerCase(),
      paper.title.toLowerCase().replace(/\s+/g, ' ').trim(),
      paper.url,
    ].filter(Boolean).join('|');
    if (seen.has(key)) continue;
    seen.add(key);
    out.push(paper);
  }
  return out;
}

function byRecent(a: ScientificPaper, b: ScientificPaper): number {
  const ad = a.publishedDate ? Date.parse(a.publishedDate) : 0;
  const bd = b.publishedDate ? Date.parse(b.publishedDate) : 0;
  return bd - ad;
}

function byCitations(a: ScientificPaper, b: ScientificPaper): number {
  return (b.citationCount ?? -1) - (a.citationCount ?? -1);
}

function byScore(a: ScientificPaper, b: ScientificPaper): number {
  return (b.score ?? -1) - (a.score ?? -1);
}

function sortResults(papers: ScientificPaper[], sortBy: SearchFilters['sortBy']): ScientificPaper[] {
  const sorted = [...papers];
  if (sortBy === 'recent') return sorted.sort(byRecent);
  if (sortBy === 'citations') return sorted.sort(byCitations);
  return sorted.sort((a, b) => {
    const scoreDiff = byScore(a, b);
    if (scoreDiff !== 0) return scoreDiff;
    return byRecent(a, b);
  });
}

function inYearRange(paper: ScientificPaper, filters: SearchFilters): boolean {
  const year = paper.year;
  const from = filters.yearFrom ? Number(filters.yearFrom) : null;
  const to = filters.yearTo ? Number(filters.yearTo) : null;
  if (from && (!year || year < from)) return false;
  if (to && (!year || year > to)) return false;
  if (filters.openAccessOnly && !paper.openAccess) return false;
  return true;
}

async function fetchJson(url: string): Promise<any> {
  const res = await fetch(url, {
    headers: {
      'User-Agent': 'Scientific Browser v2 (educational project)',
      Accept: 'application/json, text/xml, application/xml;q=0.9, */*;q=0.8',
    },
  });
  if (!res.ok) {
    throw new Error(`${res.status} ${res.statusText}`);
  }
  const text = await res.text();
  try {
    return JSON.parse(text);
  } catch {
    return text;
  }
}

function extractXmlTag(block: string, tag: string): string {
  const match = block.match(new RegExp(`<${tag}[^>]*>([\s\S]*?)<\/${tag}>`, 'i'));
  return match?.[1]?.replace(/<!\[CDATA\[|\]\]>/g, '').replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim() ?? '';
}

function extractXmlTags(block: string, tag: string): string[] {
  const matches = Array.from(block.matchAll(new RegExp(`<${tag}[^>]*>([\s\S]*?)<\/${tag}>`, 'gi')));
  return matches.map((m) => m[1].replace(/<!\[CDATA\[|\]\]>/g, '').replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim()).filter(Boolean);
}

function arxivParse(feed: string): ScientificPaper[] {
  const entries = feed.split('<entry>').slice(1).map((chunk) => chunk.split('</entry>')[0]);
  return entries.map((entry) => {
    const id = extractXmlTag(entry, 'id');
    const title = extractXmlTag(entry, 'title');
    const summary = extractXmlTag(entry, 'summary');
    const published = extractXmlTag(entry, 'published');
    const authors = extractXmlTags(entry, 'name').map((name) => ({ name }));
    const links = Array.from(entry.matchAll(/<link\s+([^>]+?)\/?\s*>/gi)).map((m) => m[1]);
    const pdfMatch = links.find((chunk) => /title=["']pdf["']/i.test(chunk) || /type=["']application\/pdf["']/i.test(chunk));
    const pdfUrl = pdfMatch?.match(/href=["']([^"']+)["']/i)?.[1] ?? null;
    const categories = Array.from(entry.matchAll(/<category\s+[^>]*term=["']([^"']+)["']/gi)).map((m) => m[1]);
    const doi = extractXmlTag(entry, 'arxiv:doi') || null;
    return {
      id: `arxiv:${id || crypto.randomUUID()}`,
      source: 'arxiv',
      title,
      authors,
      abstract: summary || 'No abstract available.',
      year: published ? new Date(published).getFullYear() : null,
      venue: 'arXiv',
      doi,
      url: id || '#',
      pdfUrl,
      citationCount: null,
      openAccess: true,
      keywords: categories,
      publishedDate: published || null,
      score: null,
    };
  });
}

async function searchOpenAlex(query: string, limit: number): Promise<ScientificPaper[]> {
  const url = new URL('https://api.openalex.org/works');
  url.searchParams.set('search', query);
  url.searchParams.set('per-page', String(limit));
  url.searchParams.set('sort', 'relevance_score:desc');
  url.searchParams.set('select', 'id,doi,display_name,authorships,abstract_inverted_index,publication_year,publication_date,best_oa_location,primary_location,open_access,cited_by_count,host_venue,concepts,relevance_score');
  const data = await fetchJson(url.toString());
  const items = Array.isArray(data?.results) ? data.results : [];
  return items.map(normalizeOpenAlex);
}

async function searchCrossref(query: string, limit: number): Promise<ScientificPaper[]> {
  const url = new URL('https://api.crossref.org/works');
  url.searchParams.set('query', query);
  url.searchParams.set('rows', String(limit));
  url.searchParams.set('select', 'DOI,title,author,abstract,container-title,created,published,URL,type,is-referenced-by-count,link');
  const data = await fetchJson(url.toString());
  const items = Array.isArray(data?.message?.items) ? data.message.items : [];
  return items.map(normalizeCrossref);
}

async function searchArxiv(query: string, limit: number): Promise<ScientificPaper[]> {
  const url = new URL('https://export.arxiv.org/api/query');
  url.searchParams.set('search_query', `all:${query}`);
  url.searchParams.set('start', '0');
  url.searchParams.set('max_results', String(limit));
  url.searchParams.set('sortBy', 'relevance');
  url.searchParams.set('sortOrder', 'descending');
  const res = await fetch(url.toString(), {
    headers: {
      'User-Agent': 'Scientific Browser v2 (educational project)',
      Accept: 'application/atom+xml, application/xml;q=0.9, */*;q=0.8',
    },
  });
  if (!res.ok) {
    throw new Error(`${res.status} ${res.statusText}`);
  }
  const feed = await res.text();
  return arxivParse(feed);
}

async function searchPubMed(query: string, limit: number): Promise<ScientificPaper[]> {
  const searchUrl = new URL('https://eutils.ncbi.nlm.nih.gov/entrez/eutils/esearch.fcgi');
  searchUrl.searchParams.set('db', 'pubmed');
  searchUrl.searchParams.set('term', query);
  searchUrl.searchParams.set('retmode', 'json');
  searchUrl.searchParams.set('retmax', String(limit));
  searchUrl.searchParams.set('sort', 'relevance');
  const searchData = await fetchJson(searchUrl.toString());
  const ids: string[] = searchData?.esearchresult?.idlist ?? [];
  if (!ids.length) return [];

  const fetchUrl = new URL('https://eutils.ncbi.nlm.nih.gov/entrez/eutils/efetch.fcgi');
  fetchUrl.searchParams.set('db', 'pubmed');
  fetchUrl.searchParams.set('id', ids.join(','));
  fetchUrl.searchParams.set('retmode', 'xml');
  const res = await fetch(fetchUrl.toString(), {
    headers: {
      'User-Agent': 'Scientific Browser v2 (educational project)',
      Accept: 'application/xml, text/xml;q=0.9, */*;q=0.8',
    },
  });
  if (!res.ok) throw new Error(`${res.status} ${res.statusText}`);
  const xml = await res.text();
  const articles = xml.split('<PubmedArticle>').slice(1).map((chunk) => chunk.split('</PubmedArticle>')[0]);
  return articles.map((article) => {
    const pmid = extractXmlTag(article, 'PMID');
    const title = extractXmlTag(article, 'ArticleTitle');
    const abstractParts = Array.from(article.matchAll(/<AbstractText[^>]*>([\s\S]*?)<\/AbstractText>/gi)).map((m) => m[1].replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim());
    const journal = extractXmlTag(article, 'Title');
    const pubDate = extractXmlTag(article, 'PubDate');
    const yearMatch = pubDate.match(/(19|20)\d{2}/);
    const authors = Array.from(article.matchAll(/<Author>[\s\S]*?<LastName>(.*?)<\/LastName>[\s\S]*?<Initials>(.*?)<\/Initials>[\s\S]*?<\/Author>/gi)).map((m) => ({
      name: `${m[2]} ${m[1]}`.trim(),
    }));
    const doiMatch = article.match(/<ArticleId IdType="doi">([\s\S]*?)<\/ArticleId>/i);
    const pmcMatch = article.match(/<ArticleId IdType="pmc">([\s\S]*?)<\/ArticleId>/i);
    return {
      id: `pubmed:${pmid || crypto.randomUUID()}`,
      source: 'pubmed' as const,
      title,
      authors,
      abstract: abstractParts.join('\n\n') || 'No abstract available.',
      year: yearMatch ? Number(yearMatch[0]) : null,
      venue: journal || null,
      doi: doiMatch?.[1] ?? null,
      url: pmid ? `https://pubmed.ncbi.nlm.nih.gov/${pmid}/` : '#',
      pdfUrl: pmcMatch?.[1] ? `https://pmc.ncbi.nlm.nih.gov/articles/${pmcMatch[1]}/pdf/` : null,
      citationCount: null,
      openAccess: Boolean(pmcMatch?.[1]),
      keywords: [],
      publishedDate: yearMatch ? `${yearMatch[0]}-01-01` : null,
      score: null,
    };
  });
}

export async function searchScientificPapers(filters: SearchFilters): Promise<{ results: ScientificPaper[]; errors: string[]; }> {
  const query = filters.query.trim();
  if (!query) return { results: [], errors: [] };
  const limit = clampLimit(filters.limit);
  const sources: ScientificSource[] = filters.source === 'all'
    ? ['openalex', 'crossref', 'arxiv', 'pubmed']
    : [filters.source];

  const tasks = sources.map(async (source) => {
    switch (source) {
      case 'openalex':
        return await searchOpenAlex(query, limit);
      case 'crossref':
        return await searchCrossref(query, limit);
      case 'arxiv':
        return await searchArxiv(query, limit);
      case 'pubmed':
        return await searchPubMed(query, limit);
      default:
        return [];
    }
  });

  const settled = await Promise.allSettled(tasks);
  const errors: string[] = [];
  const allResults: ScientificPaper[] = [];
  settled.forEach((result, index) => {
    if (result.status === 'fulfilled') {
      allResults.push(...result.value);
      return;
    }
    errors.push(`${sources[index]}: ${result.reason instanceof Error ? result.reason.message : 'Unknown error'}`);
  });

  const filtered = dedupePapers(allResults).filter((paper) => inYearRange(paper, filters));
  const results = sortResults(filtered, filters.sortBy).slice(0, limit);
  return { results, errors };
}

export function buildScientificVideos(query: string, papers: ScientificPaper[]): ScientificVideo[] {
  return buildVideoRecommendations(query, papers);
}
