import type { ScientificPaper } from './types';

function authorsAsText(paper: ScientificPaper): string {
  if (!paper.authors.length) return 'Unknown author';
  return paper.authors.map((author) => author.name).join(', ');
}

function yearText(paper: ScientificPaper): string {
  return paper.year ? `(${paper.year})` : '(n.d.)';
}

export function formatApaCitation(paper: ScientificPaper): string {
  const authors = authorsAsText(paper);
  const title = paper.title.replace(/\s+/g, ' ').trim();
  const venue = paper.venue ? `${paper.venue}.` : '';
  const doi = paper.doi ? ` https://doi.org/${paper.doi}` : '';
  return `${authors} ${yearText(paper)}. ${title}. ${venue}${doi}`.replace(/\s+/g, ' ').trim();
}

export function formatIeeeCitation(paper: ScientificPaper): string {
  const authors = authorsAsText(paper);
  const title = paper.title.replace(/\s+/g, ' ').trim();
  const venue = paper.venue ? `, ${paper.venue}` : '';
  const year = paper.year ? `, ${paper.year}` : ', n.d.';
  const doi = paper.doi ? `. doi: ${paper.doi}` : '';
  return `${authors}, "${title}"${venue}${year}${doi}`;
}

export function formatBibTexCitation(paper: ScientificPaper): string {
  const firstAuthor = paper.authors[0]?.name?.split(' ')[0]?.toLowerCase() ?? 'paper';
  const year = paper.year ?? 'n.d.';
  const key = `${firstAuthor}${year}${paper.title.split(/\s+/)[0]?.toLowerCase() ?? 'paper'}`.replace(/[^a-z0-9]+/g, '');
  const authors = paper.authors.map((author) => author.name).join(' and ');
  const title = paper.title.replace(/[{}\/]/g, '');
  const venue = paper.venue ? paper.venue.replace(/[{}\/]/g, '') : '';
  const doi = paper.doi ? `  doi = {${paper.doi}},` : '';
  return `@article{${key},\n  title = {${title}},\n  author = {${authors}},\n  journal = {${venue}},\n  year = {${year}},${doi}\n}`;
}

export function citationFormats(paper: ScientificPaper) {
  return {
    apa: formatApaCitation(paper),
    ieee: formatIeeeCitation(paper),
    bibtex: formatBibTexCitation(paper),
  };
}
