import type { ScientificPaper, ScientificVideo } from './types';

const SOURCES = [
  {
    channel: 'MIT OpenCourseWare',
    provider: 'MIT',
    buildUrl(topic: string) {
      return `https://ocw.mit.edu/search/?q=${encodeURIComponent(topic)}`;
    },
  },
  {
    channel: 'Nature Video',
    provider: 'Nature',
    buildUrl(topic: string) {
      return `https://www.nature.com/search?journal=video&q=${encodeURIComponent(topic)}`;
    },
  },
  {
    channel: 'Khan Academy',
    provider: 'Khan Academy',
    buildUrl(topic: string) {
      return `https://www.khanacademy.org/search?page_search_query=${encodeURIComponent(topic)}`;
    },
  },
  {
    channel: 'Stanford Online',
    provider: 'Stanford',
    buildUrl(topic: string) {
      return `https://online.stanford.edu/search?keys=${encodeURIComponent(topic)}`;
    },
  },
  {
    channel: 'NPTEL',
    provider: 'NPTEL',
    buildUrl(topic: string) {
      return `https://nptel.ac.in/search?query=${encodeURIComponent(topic)}`;
    },
  },
  {
    channel: 'NIH',
    provider: 'NIH',
    buildUrl(topic: string) {
      return `https://www.nih.gov/search?query=${encodeURIComponent(topic)}`;
    },
  },
];

function topicFromPaper(paper: ScientificPaper): string {
  const parts = [paper.title, paper.abstract, ...paper.keywords].join(' ').toLowerCase();
  if (/(cell|gene|protein|medical|biology|clinical|pubmed)/.test(parts)) return 'biomedical research';
  if (/(quantum|physics|astronomy|cosmology|particle)/.test(parts)) return 'physics and astronomy';
  if (/(chemistry|material|nanotech|polymer|battery)/.test(parts)) return 'chemistry and materials';
  if (/(robot|vision|transformer|machine learning|deep learning|nlp|ai)/.test(parts)) return 'machine learning and AI';
  return 'scientific education';
}

function topicSlug(topic: string): string {
  return topic.trim().toLowerCase().replace(/[^a-z0-9\u0600-\u06FF]+/g, '-').replace(/-+/g, '-').replace(/^-|-$/g, '') || 'scientific-education';
}

export function buildVideoRecommendations(query: string, papers: ScientificPaper[]): ScientificVideo[] {
  const topic = papers.length ? topicFromPaper(papers[0]) : (query || 'scientific education');
  const slug = topicSlug(topic);
  return SOURCES.map((source, index) => {
    const external = source.buildUrl(topic);
    return {
      id: `video:${index}:${slug}`,
      title: `${source.channel} — ${topic}`,
      source: 'trusted-source' as const,
      topic,
      channel: source.channel,
      summary: `Open a trusted scientific resource from ${source.provider} inside the platform and keep the browsing flow in one workspace.`,
      url: `/videos?topic=${encodeURIComponent(topic)}&source=${encodeURIComponent(source.channel)}`,
      provider: source.provider,
      embedUrl: external,
      duration: null,
    };
  });
}
