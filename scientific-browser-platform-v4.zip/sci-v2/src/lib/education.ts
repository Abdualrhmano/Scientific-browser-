export interface LearningTrack {
  title: string;
  description: string;
  audience: string;
  topics: string[];
  resources: Array<{ label: string; url: string }>;
}

export const learningTracks: LearningTrack[] = [
  {
    title: 'Research Foundations',
    description: 'How to read, evaluate, and organize scientific papers efficiently.',
    audience: 'Students, researchers, and literature reviewers',
    topics: ['Search strategy', 'Literature review', 'Citation management', 'Paper reading workflow'],
    resources: [
      { label: 'PubMed search', url: 'https://pubmed.ncbi.nlm.nih.gov/' },
      { label: 'OpenAlex works', url: 'https://openalex.org/' },
      { label: 'Crossref', url: 'https://www.crossref.org/' },
    ],
  },
  {
    title: 'AI for Science',
    description: 'Using AI to summarize papers, compare methods, and accelerate knowledge discovery.',
    audience: 'AI practitioners and scientific teams',
    topics: ['Summarization', 'RAG', 'Embedding search', 'Scientific assistants'],
    resources: [
      { label: 'arXiv', url: 'https://arxiv.org/' },
      { label: 'Semantic Scholar', url: 'https://www.semanticscholar.org/' },
      { label: 'OpenAI API docs', url: 'https://platform.openai.com/docs' },
    ],
  },
  {
    title: 'Scientific Learning',
    description: 'A structured pathway for formal study, lectures, and open courseware.',
    audience: 'Learners around the world',
    topics: ['Lectures', 'Explanations', 'Assignments', 'Self-study'],
    resources: [
      { label: 'MIT OpenCourseWare', url: 'https://ocw.mit.edu/' },
      { label: 'Khan Academy', url: 'https://www.khanacademy.org/' },
      { label: 'NPTEL', url: 'https://nptel.ac.in/' },
    ],
  },
  {
    title: 'Writing and Publishing',
    description: 'Writing better papers, managing citations, and preparing submission-ready drafts.',
    audience: 'Graduate students and publishing teams',
    topics: ['APA', 'IEEE', 'BibTeX', 'Journal selection'],
    resources: [
      { label: 'DOAJ', url: 'https://doaj.org/' },
      { label: 'Europe PMC', url: 'https://europepmc.org/' },
      { label: 'NCBI PubMed', url: 'https://pubmed.ncbi.nlm.nih.gov/' },
    ],
  },
];
