import type { ScientificAuthor, ScientificPaper } from './types';

function cleanArray<T>(value: T[] | undefined | null): T[] {
  return Array.isArray(value) ? value.filter(Boolean) : [];
}

function authorsFromOpenAlex(item: any): ScientificAuthor[] {
  return cleanArray<any>(item?.authorships).map((entry: any) => ({
    name: String(entry?.author?.display_name ?? 'Unknown'),
    affiliation: entry?.institutions?.[0]?.display_name ? String(entry.institutions[0].display_name) : null,
  }));
}

function authorsFromCrossref(item: any): ScientificAuthor[] {
  return cleanArray<any>(item?.author).map((entry: any) => ({
    name: [entry?.given, entry?.family].filter(Boolean).join(' ') || 'Unknown',
    affiliation: entry?.affiliation?.[0]?.name ? String(entry.affiliation[0].name) : null,
  }));
}

function authorsFromPubMed(item: any): ScientificAuthor[] {
  return cleanArray<any>(item?.authors).map((entry: any) => ({
    name: String(entry?.name ?? entry?.fullName ?? entry?.author ?? 'Unknown'),
    affiliation: entry?.affiliation ? String(entry.affiliation) : null,
  }));
}

export function abstractFromOpenAlex(item: any): string {
  const inverted = item?.abstract_inverted_index;
  if (!inverted || typeof inverted !== 'object') return String(item?.abstract || '');
  const words: string[] = [];
  Object.entries(inverted)
    .sort((a, b) => {
      const posA = Array.isArray(a[1]) ? Number(a[1][0] ?? 0) : 0;
      const posB = Array.isArray(b[1]) ? Number(b[1][0] ?? 0) : 0;
      return posA - posB;
    })
    .forEach(([word, positions]) => {
      if (!Array.isArray(positions)) return;
      positions.forEach((pos) => {
        words[pos] = String(word);
      });
    });
  return words.filter(Boolean).join(' ');
}

export function normalizeOpenAlex(item: any): ScientificPaper {
  const best = item?.best_oa_location ?? item?.primary_location ?? null;
  const pdfUrl = best?.pdf_url ?? best?.landing_page_url ?? null;
  return {
    id: `openalex:${item?.id ?? crypto.randomUUID()}`,
    source: 'openalex',
    title: String(item?.display_name ?? item?.title ?? 'Untitled work'),
    authors: authorsFromOpenAlex(item),
    abstract: abstractFromOpenAlex(item) || 'No abstract available.',
    year: item?.publication_year ?? null,
    venue: item?.host_venue?.display_name ? String(item.host_venue.display_name) : null,
    doi: item?.doi ? String(item.doi) : null,
    url: item?.id ? String(item.id) : item?.primary_location?.landing_page_url ? String(item.primary_location.landing_page_url) : '#',
    pdfUrl: pdfUrl ? String(pdfUrl) : null,
    citationCount: item?.cited_by_count ?? null,
    openAccess: Boolean(item?.open_access?.is_oa),
    keywords: cleanArray<any>(item?.concepts)
      .slice(0, 6)
      .map((concept: any) => concept?.display_name)
      .filter((value): value is string => Boolean(value))
      .map((value) => String(value)),
    publishedDate: item?.publication_date ? String(item.publication_date) : null,
    score: item?.relevance_score ?? null,
  };
}

export function normalizeCrossref(item: any): ScientificPaper {
  const title = cleanArray<string>(item?.title)[0] ?? 'Untitled work';
  const venue = cleanArray<string>(item?.['container-title'])[0] ?? null;
  const date = item?.created?.['date-time'] ?? item?.published?.['date-time'] ?? null;
  const doi = item?.DOI ?? null;
  return {
    id: `crossref:${doi ?? crypto.randomUUID()}`,
    source: 'crossref',
    title: String(title),
    authors: authorsFromCrossref(item),
    abstract: String(item?.abstract ?? '').replace(/<[^>]+>/g, '').trim() || 'No abstract available.',
    year: date ? new Date(String(date)).getFullYear() : null,
    venue: venue ? String(venue) : null,
    doi: doi ? String(doi) : null,
    url: item?.URL ? String(item.URL) : doi ? `https://doi.org/${doi}` : '#',
    pdfUrl: null,
    citationCount: item?.['is-referenced-by-count'] ?? null,
    openAccess: Array.isArray(item?.link) && item.link.some((l: any) => String(l?.URL || '').toLowerCase().includes('pdf')),
    keywords: [],
    publishedDate: date ? String(date) : null,
    score: null,
  };
}

export function normalizeArxiv(item: any): ScientificPaper {
  const pdfLink = cleanArray<any>(item.links).find((link: any) => link?.type === 'application/pdf')?.href ?? null;
  const authors = cleanArray<any>(item.authors).map((name: any) => ({ name: String(name) }));
  return {
    id: `arxiv:${item.id ?? crypto.randomUUID()}`,
    source: 'arxiv',
    title: String(item.title ?? 'Untitled work'),
    authors,
    abstract: String(item.summary ?? 'No abstract available.'),
    year: item.published ? new Date(String(item.published)).getFullYear() : null,
    venue: 'arXiv',
    doi: item.doi ? String(item.doi) : null,
    url: item.id ? String(item.id) : '#',
    pdfUrl: pdfLink ? String(pdfLink) : null,
    citationCount: null,
    openAccess: true,
    keywords: cleanArray<string>(item.categories).map((category) => String(category)),
    publishedDate: item.published ? String(item.published) : null,
    score: null,
  };
}

export function normalizePubMed(item: any): ScientificPaper {
  const title = item?.title ?? 'Untitled work';
  const authors = authorsFromPubMed(item);
  const doi = item?.doi ?? null;
  return {
    id: `pubmed:${item?.pmid ?? crypto.randomUUID()}`,
    source: 'pubmed',
    title: String(title),
    authors,
    abstract: String(item?.abstract ?? 'No abstract available.'),
    year: item?.year ?? null,
    venue: item?.journal ? String(item.journal) : null,
    doi: doi ? String(doi) : null,
    url: item?.url ? String(item.url) : item?.pmid ? `https://pubmed.ncbi.nlm.nih.gov/${item.pmid}/` : '#',
    pdfUrl: item?.pmcUrl ? String(item.pmcUrl) : null,
    citationCount: item?.citationCount ?? null,
    openAccess: Boolean(item?.openAccess),
    keywords: cleanArray<string>(item?.keywords).map((keyword) => String(keyword)),
    publishedDate: item?.publishedDate ? String(item.publishedDate) : null,
    score: item?.score ?? null,
  };
}
