import type { ScientificPaper } from './types';

type PaperBuffer = {
  from(input: string, encoding: 'utf8' | 'base64url'): { toString(encoding: 'base64url' | 'utf8'): string };
};

function getBuffer(): PaperBuffer | null {
  const maybeGlobal = globalThis as typeof globalThis & { Buffer?: PaperBuffer };
  return maybeGlobal.Buffer ?? null;
}

function toBase64Url(input: string): string {
  const buffer = getBuffer();
  if (buffer) {
    return buffer.from(input, 'utf8').toString('base64url');
  }

  const bytes = new TextEncoder().encode(input);
  let binary = '';
  bytes.forEach((byte) => {
    binary += String.fromCharCode(byte);
  });
  return btoa(binary).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
}

function fromBase64Url(input: string): string {
  const buffer = getBuffer();
  if (buffer) {
    return buffer.from(input, 'base64url').toString('utf8');
  }

  const normalized = input.replace(/-/g, '+').replace(/_/g, '/');
  const padded = normalized + '='.repeat((4 - (normalized.length % 4)) % 4);
  const binary = atob(padded);
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i += 1) {
    bytes[i] = binary.charCodeAt(i);
  }
  return new TextDecoder().decode(bytes);
}

export function encodePaperSlug(paper: ScientificPaper): string {
  return toBase64Url(JSON.stringify(paper));
}

export function decodePaperSlug(slug: string): ScientificPaper | null {
  try {
    const raw = fromBase64Url(slug);
    const parsed = JSON.parse(raw) as ScientificPaper;
    if (!parsed || typeof parsed !== 'object') return null;
    return parsed;
  } catch {
    return null;
  }
}
