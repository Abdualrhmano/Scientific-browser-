export type ScientificSource = 'all' | 'openalex' | 'crossref' | 'arxiv' | 'pubmed';

export interface ScientificAuthor {
  name: string;
  affiliation?: string | null;
}

export interface ScientificPaper {
  id: string;
  source: Exclude<ScientificSource, 'all'>;
  title: string;
  authors: ScientificAuthor[];
  abstract: string;
  year: number | null;
  venue: string | null;
  doi: string | null;
  url: string;
  pdfUrl: string | null;
  citationCount: number | null;
  openAccess: boolean;
  keywords: string[];
  publishedDate: string | null;
  score: number | null;
}

export interface ScientificVideo {
  id: string;
  title: string;
  source: 'youtube-search' | 'trusted-source';
  topic: string;
  channel: string;
  summary: string;
  url: string;
  provider?: string;
  embedUrl?: string | null;
  duration?: string | null;
}

export interface SearchFilters {
  query: string;
  source: ScientificSource;
  yearFrom: string;
  yearTo: string;
  openAccessOnly: boolean;
  sortBy: 'relevance' | 'citations' | 'recent';
  limit: number;
}

export interface SearchResponse {
  query: string;
  source: ScientificSource;
  total: number;
  results: ScientificPaper[];
  videos: ScientificVideo[];
  errors: string[];
}
