export interface TranslationResult {
  translatedText: string;
  detectedSourceLanguage: string;
  targetLanguage: string;
  provider: 'mymemory' | 'fallback';
  confidence: number | null;
}

export interface TranslatePayload {
  text: string;
  sourceLanguage?: string;
  targetLanguage: string;
}

export function inferLanguage(text: string): 'ar' | 'en' {
  return /[\u0600-\u06FF]/.test(text) ? 'ar' : 'en';
}

export async function translateScientificText(payload: TranslatePayload): Promise<TranslationResult> {
  const response = await fetch('/api/translate', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', Accept: 'application/json' },
    body: JSON.stringify(payload),
  });

  if (!response.ok) {
    const message = await response.text().catch(() => '');
    throw new Error(message || `Translation request failed (${response.status})`);
  }

  return (await response.json()) as TranslationResult;
}
