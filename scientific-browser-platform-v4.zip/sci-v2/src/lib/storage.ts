import type { ScientificPaper } from './types';

const STORAGE_KEY = 'scientific-browser-v2';

export interface PersistedState {
  savedPapers: ScientificPaper[];
  queryHistory: string[];
  darkMode: boolean;
}

export function loadPersistedState(): PersistedState {
  if (typeof window === 'undefined') {
    return { savedPapers: [], queryHistory: [], darkMode: true };
  }

  try {
    const raw = window.localStorage.getItem(STORAGE_KEY);
    if (!raw) return { savedPapers: [], queryHistory: [], darkMode: true };
    const parsed = JSON.parse(raw) as Partial<PersistedState>;
    return {
      savedPapers: Array.isArray(parsed.savedPapers) ? parsed.savedPapers : [],
      queryHistory: Array.isArray(parsed.queryHistory) ? parsed.queryHistory.slice(0, 10) : [],
      darkMode: typeof parsed.darkMode === 'boolean' ? parsed.darkMode : true,
    };
  } catch {
    return { savedPapers: [], queryHistory: [], darkMode: true };
  }
}

export function savePersistedState(state: PersistedState): void {
  if (typeof window === 'undefined') return;
  window.localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
}
