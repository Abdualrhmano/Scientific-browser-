import type { ScientificPaper } from './types';
import { authorList, yearLabel } from './format';

function firstSentence(text: string): string {
  const trimmed = text.replace(/\s+/g, ' ').trim();
  if (!trimmed) return 'No abstract available.';
  const match = trimmed.match(/^(.+?[.!?])\s/);
  return match?.[1] ?? trimmed.slice(0, 220).trim();
}

export function buildReadingSummary(paper: ScientificPaper): string {
  const intro = firstSentence(paper.abstract);
  const venue = paper.venue ? ` It appears in ${paper.venue}` : '';
  const year = paper.year ? ` (${yearLabel(paper.year)})` : '';
  return `${paper.title}${year} is a research paper by ${authorList(paper.authors, 4)}.${venue} The abstract begins with: ${intro}`;
}

export function buildKeyInsights(paper: ScientificPaper): string[] {
  const text = `${paper.title} ${paper.abstract} ${paper.keywords.join(' ')}`.toLowerCase();
  const insights: string[] = [];

  const topicPatterns: Array<[RegExp, string]> = [
    [/(transformer|llm|language model|nlp|embedding)/, 'The paper is centered on modern language-model or representation learning methods.'],
    [/(medical|clinical|patient|disease|biomedical|pubmed|health)/, 'The paper has a biomedical or clinical research focus.'],
    [/(quantum|physics|astronomy|cosmology|particle)/, 'The paper appears to contribute to physics or astronomy.'],
    [/(chemistry|material|polymer|nanotech|battery)/, 'The paper appears to cover chemistry, materials, or nanotechnology.'],
    [/(robot|vision|control|sensor|autonomous)/, 'The paper is likely connected to robotics, computer vision, or control systems.'],
  ];

  for (const [pattern, insight] of topicPatterns) {
    if (pattern.test(text)) {
      insights.push(insight);
      break;
    }
  }

  if (paper.openAccess) {
    insights.push('An open-access version or landing page is likely available from the source.');
  } else {
    insights.push('Check the source page and DOI for availability of a legal PDF or publisher landing page.');
  }

  if (paper.citationCount !== null) {
    insights.push(`This paper has been cited ${paper.citationCount} time${paper.citationCount === 1 ? '' : 's'} according to the indexed source.`);
  } else {
    insights.push('Citation count was not available from the current source.');
  }

  const firstKeywords = paper.keywords.slice(0, 5);
  if (firstKeywords.length) {
    insights.push(`Key terms include: ${firstKeywords.join(', ')}.`);
  }

  if (insights.length < 3) {
    insights.push('A quick reading path is to review the abstract, then jump to the methods and results sections.');
  }

  return insights.slice(0, 5);
}
