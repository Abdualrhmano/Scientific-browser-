'use client';

import { useMemo, useState } from 'react';
import { useSearchParams } from 'next/navigation';
import { PlayCircle, Search, ExternalLink, LibraryBig } from 'lucide-react';
import { PageShell, MetricCard, SectionHeading, InlinePill } from '@/shared/components/PageShell';
import { buildVideoRecommendations } from '@/lib/videos';
import { ScientificPaper } from '@/lib/types';

function pickTopic(query: string | null) {
  const value = query?.trim();
  return value || 'scientific education';
}

export default function VideosPage() {
  const searchParams = useSearchParams();
  const [query, setQuery] = useState(searchParams.get('topic') ?? '');
  const [selectedIndex, setSelectedIndex] = useState(0);

  const videos = useMemo(() => buildVideoRecommendations(pickTopic(query), [] as ScientificPaper[]), [query]);
  const selectedVideo = videos[selectedIndex] ?? videos[0];

  return (
    <PageShell
      eyebrow="Scientific media"
      title="Trusted Video Library"
      description="Discover educational video resources from trusted scientific and academic sources without leaving the platform."
      action={<MetricCard label="Sources" value={String(videos.length)} />}
    >
      <section className="grid gap-4 md:grid-cols-3">
        <MetricCard label="Topic" value={pickTopic(query)} />
        <MetricCard label="Current video" value={selectedVideo?.channel || 'n/a'} />
        <MetricCard label="Mode" value="In-app preview" />
      </section>

      <section className="mt-6 grid gap-6 xl:grid-cols-[0.78fr_1.22fr]">
        <div className="rounded-3xl border border-white/10 bg-white/5 p-6 shadow-soft">
          <SectionHeading
            eyebrow="Video search"
            title="Find educational content"
            description="Type a scientific topic and keep the result inside this workspace."
          />
          <div className="mt-5 flex gap-3">
            <div className="relative flex-1">
              <Search className="pointer-events-none absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
              <input
                value={query}
                onChange={(event) => {
                  setQuery(event.target.value);
                  setSelectedIndex(0);
                }}
                placeholder="machine learning, biology, physics..."
                className="w-full rounded-2xl border border-white/10 bg-[#0a1220] py-3 pl-11 pr-4 text-white outline-none placeholder:text-slate-500 focus:border-primary-400/50"
              />
            </div>
          </div>

          <div className="mt-6 grid gap-3">
            {videos.map((video, index) => (
              <button
                key={video.id}
                type="button"
                onClick={() => setSelectedIndex(index)}
                className={`rounded-2xl border p-4 text-left transition ${
                  index === selectedIndex ? 'border-primary-400 bg-primary-500/10' : 'border-white/10 bg-white/5 hover:bg-white/10'
                }`}
              >
                <div className="flex items-center justify-between gap-4">
                  <div>
                    <InlinePill>{video.channel}</InlinePill>
                    <div className="mt-3 text-base font-semibold text-white">{video.title}</div>
                  </div>
                  <PlayCircle className="text-primary-300" size={18} />
                </div>
                <p className="mt-3 text-sm leading-7 text-slate-400">{video.summary}</p>
              </button>
            ))}
          </div>
        </div>

        <div className="rounded-3xl border border-white/10 bg-white/5 p-6 shadow-soft">
          <SectionHeading
            eyebrow="Preview"
            title={selectedVideo?.title || 'Video preview'}
            description="Open the trusted source in the panel and keep the browsing experience inside the platform."
          />
          <div className="mt-5 overflow-hidden rounded-3xl border border-white/10 bg-[#09111f]">
            {selectedVideo ? (
              <iframe
                title={selectedVideo.title}
                src={selectedVideo.embedUrl || selectedVideo.url}
                className="h-[520px] w-full"
                loading="lazy"
                referrerPolicy="no-referrer"
              />
            ) : (
              <div className="flex h-[520px] items-center justify-center text-slate-400">No video selected.</div>
            )}
          </div>

          <div className="mt-5 flex flex-wrap gap-3">
            <a
              href={selectedVideo?.url || '#'}
              target="_blank"
              rel="noreferrer"
              className="inline-flex items-center gap-2 rounded-2xl bg-primary-500 px-4 py-3 text-sm font-semibold text-white transition hover:bg-primary-400"
            >
              <ExternalLink size={16} />
              Open source
            </a>
            <a
              href="/library"
              className="inline-flex items-center gap-2 rounded-2xl border border-white/10 bg-white/5 px-4 py-3 text-sm font-medium text-slate-100 transition hover:bg-white/10"
            >
              <LibraryBig size={16} />
              Back to library
            </a>
          </div>

          <div className="mt-6 rounded-2xl border border-white/10 bg-white/5 p-4 text-sm leading-7 text-slate-300">
            <div className="mb-2 text-xs uppercase tracking-[0.2em] text-slate-400">Why this matters</div>
            The platform can later replace these source pages with embeddable streams or a curated media CDN while keeping the same interface and browsing flow.
          </div>
        </div>
      </section>
    </PageShell>
  );
}
