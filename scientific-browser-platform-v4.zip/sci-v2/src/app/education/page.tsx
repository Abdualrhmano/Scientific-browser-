import Link from 'next/link';
import { BookOpen, GraduationCap, Globe2, Lightbulb, Rocket, Search } from 'lucide-react';
import { PageShell, MetricCard, SectionHeading, InlinePill } from '@/shared/components/PageShell';
import { learningTracks } from '@/lib/education';

export default function EducationPage() {
  return (
    <PageShell
      eyebrow="Learning hub"
      title="Scientific Education"
      description="A structured home for courses, study tracks, and international learning resources."
      action={<MetricCard label="Tracks" value={String(learningTracks.length)} />}
    >
      <section className="grid gap-4 md:grid-cols-4">
        <MetricCard label="Tracks" value={String(learningTracks.length)} />
        <MetricCard label="Audience" value="Global learners" />
        <MetricCard label="Focus" value="Science & education" />
        <MetricCard label="AI ready" value="Future integration" />
      </section>

      <section className="mt-6 rounded-3xl border border-white/10 bg-white/5 p-6 shadow-soft">
        <SectionHeading
          eyebrow="Overview"
          title="Study pathways"
          description="Use this area to guide students, researchers, and lifelong learners across multiple fields."
        />
        <div className="mt-5 grid gap-4 xl:grid-cols-2">
          {learningTracks.map((track) => (
            <article key={track.title} className="rounded-3xl border border-white/10 bg-[#0a1220] p-5">
              <div className="flex items-start justify-between gap-4">
                <div>
                  <InlinePill>{track.audience}</InlinePill>
                  <h3 className="mt-3 text-xl font-semibold text-white">{track.title}</h3>
                </div>
                <div className="rounded-2xl border border-white/10 bg-white/5 p-3 text-primary-200">
                  <Lightbulb size={18} />
                </div>
              </div>
              <p className="mt-4 text-sm leading-7 text-slate-300">{track.description}</p>
              <div className="mt-4 flex flex-wrap gap-2">
                {track.topics.map((topic) => (
                  <span key={topic} className="rounded-full border border-white/10 bg-white/5 px-3 py-1 text-xs text-slate-200">
                    {topic}
                  </span>
                ))}
              </div>

              <div className="mt-5 grid gap-2">
                {track.resources.map((resource) => (
                  <a
                    key={resource.label}
                    href={resource.url}
                    target="_blank"
                    rel="noreferrer"
                    className="inline-flex items-center justify-between rounded-2xl border border-white/10 bg-white/5 px-4 py-3 text-sm text-slate-100 transition hover:bg-white/10"
                  >
                    <span>{resource.label}</span>
                    <Globe2 size={14} className="text-slate-400" />
                  </a>
                ))}
              </div>
            </article>
          ))}
        </div>
      </section>

      <section className="mt-6 grid gap-6 xl:grid-cols-[0.9fr_1.1fr]">
        <div className="rounded-3xl border border-white/10 bg-white/5 p-6 shadow-soft">
          <SectionHeading
            eyebrow="Teaching mode"
            title="Future classroom tools"
            description="The platform is prepared for AI explanations, assignments, reading lists, and multilingual learning."
          />
          <div className="mt-5 grid gap-3">
            {[
              { icon: BookOpen, text: 'Reading lists and course packs' },
              { icon: Search, text: 'Topic search across papers and videos' },
              { icon: GraduationCap, text: 'Structured lessons and learning pathways' },
              { icon: Rocket, text: 'Future AI coaching and adaptive study plans' },
            ].map((item) => {
              const Icon = item.icon;
              return (
                <div key={item.text} className="rounded-2xl border border-white/10 bg-white/5 p-4 text-sm text-slate-200">
                  <div className="flex items-center gap-3">
                    <Icon size={16} className="text-primary-300" />
                    <span>{item.text}</span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        <div className="rounded-3xl border border-white/10 bg-white/5 p-6 shadow-soft">
          <SectionHeading
            eyebrow="Global access"
            title="Built for world-wide scientific learning"
            description="The design supports translation, search, citation export, and collaborative research workflows."
          />
          <div className="mt-5 rounded-3xl border border-white/10 bg-[#0a1220] p-5 text-sm leading-7 text-slate-300">
            <p>
              The next step is to connect this learning hub to live catalogues, translated abstracts, bookmarks, and suggested reading paths based on the user&apos;s research domain.
            </p>
            <p className="mt-4">
              For now, this page acts as the landing zone for education-focused workflows while keeping the same system design as the research search engine.
            </p>
          </div>

          <div className="mt-5 flex flex-wrap gap-3">
            <Link href="/" className="inline-flex items-center gap-2 rounded-2xl bg-primary-500 px-4 py-3 text-sm font-semibold text-white transition hover:bg-primary-400">
              <Search size={16} />
              Back to search
            </Link>
            <Link href="/translate" className="inline-flex items-center gap-2 rounded-2xl border border-white/10 bg-white/5 px-4 py-3 text-sm font-medium text-slate-100 transition hover:bg-white/10">
              Translate
            </Link>
          </div>
        </div>
      </section>
    </PageShell>
  );
}
