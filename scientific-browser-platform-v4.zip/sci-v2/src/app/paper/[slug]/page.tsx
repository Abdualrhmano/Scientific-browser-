import type { Metadata } from 'next';
import { notFound } from 'next/navigation';
import PaperWorkspace from '@/components/PaperWorkspace';
import { decodePaperSlug } from '@/lib/paperRoute';

export const dynamic = 'force-dynamic';

export function generateMetadata({ params }: { params: { slug: string } }): Metadata {
  const paper = decodePaperSlug(params.slug);
  if (!paper) {
    return {
      title: 'Paper details',
      description: 'Scientific paper workspace',
    };
  }
  return {
    title: `${paper.title} • Scientific Browser`,
    description: paper.abstract.slice(0, 160),
  };
}

export default function PaperPage({ params }: { params: { slug: string } }) {
  const paper = decodePaperSlug(params.slug);
  if (!paper) notFound();
  return <PaperWorkspace paper={paper!} />;
}
