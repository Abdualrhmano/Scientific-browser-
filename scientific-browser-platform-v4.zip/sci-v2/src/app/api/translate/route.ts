import { NextResponse } from 'next/server';
import { inferLanguage, type TranslatePayload } from '@/lib/translate';

export const runtime = 'nodejs';

function normalizeCode(value: string | undefined, fallback: 'ar' | 'en'): 'ar' | 'en' {
  if (value === 'ar' || value === 'en') return value;
  return fallback;
}

async function myMemoryTranslate(text: string, source: 'ar' | 'en', target: 'ar' | 'en') {
  const url = new URL('https://api.mymemory.translated.net/get');
  url.searchParams.set('q', text);
  url.searchParams.set('langpair', `${source}|${target}`);
  url.searchParams.set('de', 'scientific-browser@example.com');

  const response = await fetch(url.toString(), {
    headers: {
      Accept: 'application/json',
      'User-Agent': 'Scientific Browser v3 (educational project)',
    },
  });

  if (!response.ok) {
    throw new Error(`Translation service failed (${response.status})`);
  }

  const data = (await response.json()) as any;
  const translatedText = String(data?.responseData?.translatedText ?? '').trim();
  if (!translatedText) {
    throw new Error('Empty translation result');
  }

  return {
    translatedText,
    confidence: typeof data?.responseData?.match === 'number' ? Number(data.responseData.match) : null,
  };
}

function fallbackTranslate(text: string, target: 'ar' | 'en') {
  const prefix = target === 'ar' ? 'ترجمة تجريبية: ' : 'Translation preview: ';
  return `${prefix}${text}`.trim();
}

export async function POST(request: Request) {
  const payload = (await request.json().catch(() => null)) as TranslatePayload | null;
  const text = payload?.text?.trim() ?? '';
  if (!text) {
    return NextResponse.json({ error: 'Missing text' }, { status: 400 });
  }

  const sourceLanguage = normalizeCode(payload?.sourceLanguage, inferLanguage(text));
  const targetLanguage = normalizeCode(payload?.targetLanguage, sourceLanguage === 'ar' ? 'en' : 'ar');

  try {
    const { translatedText, confidence } = await myMemoryTranslate(text, sourceLanguage, targetLanguage);
    return NextResponse.json({
      translatedText,
      detectedSourceLanguage: sourceLanguage,
      targetLanguage,
      provider: 'mymemory',
      confidence,
    });
  } catch {
    return NextResponse.json({
      translatedText: fallbackTranslate(text, targetLanguage),
      detectedSourceLanguage: sourceLanguage,
      targetLanguage,
      provider: 'fallback',
      confidence: null,
    });
  }
}
