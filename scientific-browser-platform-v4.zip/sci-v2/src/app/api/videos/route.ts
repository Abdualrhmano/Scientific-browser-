import { NextResponse } from 'next/server';

export const runtime = 'nodejs';

const CHANNELS = [
  'MIT OpenCourseWare',
  'Nature Video',
  'Khan Academy',
  'Stanford Online',
  'NPTEL',
  'Veritasium',
];

export async function GET(request: Request) {
  const url = new URL(request.url);
  const query = (url.searchParams.get('q') ?? '').trim();
  const topic = query || 'scientific education';

  const videos = CHANNELS.map((channel, index) => ({
    id: `video:${index}:${topic}`,
    title: `${channel} — ${topic}`,
    source: 'youtube-search',
    channel,
    topic,
    summary: `Open a YouTube search for ${topic} from ${channel}.`,
    url: `https://www.youtube.com/results?search_query=${encodeURIComponent(`${topic} ${query}`.trim())}`,
  }));

  return NextResponse.json({ query, videos });
}
