import { NextResponse } from 'next/server';
import type { SearchFilters } from '@/lib/types';
import { buildScientificVideos, searchScientificPapers } from '@/lib/search';

export const runtime = 'nodejs';

export async function GET(request: Request) {
  const url = new URL(request.url);
  const query = (url.searchParams.get('q') ?? '').trim();
  const source = (url.searchParams.get('source') ?? 'all') as SearchFilters['source'];
  const yearFrom = url.searchParams.get('yearFrom') ?? '';
  const yearTo = url.searchParams.get('yearTo') ?? '';
  const openAccessOnly = url.searchParams.get('openAccessOnly') === 'true';
  const sortBy = (url.searchParams.get('sortBy') ?? 'relevance') as SearchFilters['sortBy'];
  const limit = Number(url.searchParams.get('limit') ?? 12);

  if (!query) {
    return NextResponse.json({
      query,
      source,
      total: 0,
      results: [],
      videos: [],
      errors: [],
    });
  }

  const { results, errors } = await searchScientificPapers({
    query,
    source,
    yearFrom,
    yearTo,
    openAccessOnly,
    sortBy,
    limit,
  });

  return NextResponse.json({
    query,
    source,
    total: results.length,
    results,
    videos: buildScientificVideos(query, results),
    errors,
  });
}
