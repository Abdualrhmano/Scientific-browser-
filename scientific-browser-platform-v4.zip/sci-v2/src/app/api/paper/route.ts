import { NextResponse } from 'next/server';

export const runtime = 'nodejs';

export async function GET(request: Request) {
  const url = new URL(request.url);
  const source = url.searchParams.get('source');
  const id = url.searchParams.get('id');

  if (!source || !id) {
    return NextResponse.json({ error: 'Missing source or id' }, { status: 400 });
  }

  if (source === 'openalex' && id.startsWith('https://openalex.org/')) {
    const response = await fetch(id, {
      headers: { Accept: 'application/json' },
    });
    return NextResponse.json(await response.json());
  }

  return NextResponse.json({
    source,
    id,
    note: 'Detailed paper endpoint is scaffolded. Search results already include metadata and links.',
  });
}
