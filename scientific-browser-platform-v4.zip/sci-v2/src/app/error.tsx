'use client';

export default function Error({
  error,
  reset,
}: {
  error: Error & { digest?: string };
  reset: () => void;
}) {
  return (
    <html lang="en">
      <body className="min-h-screen bg-[#07111f] text-white">
        <div className="mx-auto flex min-h-screen max-w-3xl items-center px-6">
          <div className="space-y-5 rounded-3xl border border-white/10 bg-white/5 p-8 shadow-soft">
            <div className="text-xs uppercase tracking-[0.22em] text-slate-400">Unexpected error</div>
            <h1 className="text-3xl font-semibold">Something went wrong while loading the scientific workspace.</h1>
            <p className="text-sm leading-7 text-slate-300">{error.message}</p>
            <button
              type="button"
              onClick={reset}
              className="rounded-2xl bg-primary-500 px-5 py-3 text-sm font-semibold text-white transition hover:bg-primary-400"
            >
              Try again
            </button>
          </div>
        </div>
      </body>
    </html>
  );
}
