import ScientificBrowserApp from '@/components/ScientificBrowserApp';

export default function Page() {
  return <ScientificBrowserApp />;
}
