'use client';

import Link from 'next/link';
import { Bookmark, FileText, Search, Sparkles, Trash2 } from 'lucide-react';
import { useMemo, useState } from 'react';
import { useAppStore } from '@/store/useAppStore';
import { authorList, formatSourceLabel, yearLabel } from '@/lib/format';
import { encodePaperSlug } from '@/lib/paperRoute';
import { PageShell, MetricCard, SectionHeading, InlinePill } from '@/shared/components/PageShell';

export default function LibraryPage() {
  const { savedPapers, paperNotes, removeSavedPaper, queryHistory, clearHistory } = useAppStore();
  const [search, setSearch] = useState('');

  const filtered = useMemo(() => {
    const value = search.trim().toLowerCase();
    if (!value) return savedPapers;
    return savedPapers.filter((paper) => {
      const haystack = [paper.title, paper.abstract, paper.venue, paper.doi, paper.authors.map((author) => author.name).join(' '), paper.keywords.join(' ')].join(' ').toLowerCase();
      return haystack.includes(value);
    });
  }, [savedPapers, search]);

  const totalNotes = Object.values(paperNotes).filter((note) => note.trim().length > 0).length;

  return (
    <PageShell
      eyebrow="Research workspace"
      title="Scientific Library"
      description="Save papers, organize notes, and keep your reading workflow in one place."
      action={<MetricCard label="Saved papers" value={String(savedPapers.length)} />}
    >
      <section className="grid gap-3 md:grid-cols-3">
        <MetricCard label="Saved papers" value={String(savedPapers.length)} />
        <MetricCard label="Notes" value={String(totalNotes)} />
        <MetricCard label="History items" value={String(queryHistory.length)} />
      </section>

      <section className="mt-6 rounded-3xl border border-white/10 bg-white/5 p-6 shadow-soft">
        <SectionHeading
          eyebrow="Library search"
          title="Filter your saved papers"
          description="Search by title, abstract, author, venue, DOI, or keywords."
        />
        <div className="mt-5 flex flex-col gap-3 md:flex-row md:items-center">
          <div className="relative flex-1">
            <Search className="pointer-events-none absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
            <input
              value={search}
              onChange={(event) => setSearch(event.target.value)}
              placeholder="Search your saved library..."
              className="w-full rounded-2xl border border-white/10 bg-[#0a1220] py-3 pl-11 pr-4 text-white outline-none placeholder:text-slate-500 focus:border-primary-400/50"
            />
          </div>
          {queryHistory.length ? (
            <button
              type="button"
              onClick={clearHistory}
              className="inline-flex items-center justify-center gap-2 rounded-2xl border border-white/10 bg-white/5 px-4 py-3 text-sm font-medium text-slate-100 transition hover:bg-white/10"
            >
              <Trash2 size={16} />
              Clear search history
            </button>
          ) : null}
        </div>
      </section>

      <section className="mt-6">
        {filtered.length ? (
          <div className="grid gap-4 xl:grid-cols-2">
            {filtered.map((paper) => (
              <article key={paper.id} className="rounded-3xl border border-white/10 bg-white/5 p-5 shadow-soft">
                <div className="flex items-start justify-between gap-4">
                  <div className="space-y-2">
                    <InlinePill>{formatSourceLabel(paper.source)}</InlinePill>
                    <h3 className="text-xl font-semibold leading-tight text-white">{paper.title}</h3>
                    <p className="text-sm leading-7 text-slate-300">{authorList(paper.authors, 6)}</p>
                  </div>
                  <button
                    type="button"
                    onClick={() => removeSavedPaper(paper.id)}
                    className="rounded-xl border border-white/10 p-2 text-slate-300 transition hover:bg-white/10"
                    aria-label="Remove from library"
                  >
                    <Trash2 size={16} />
                  </button>
                </div>

                <p className="mt-4 line-clamp-3 text-sm leading-7 text-slate-300">{paper.abstract}</p>

                <div className="mt-4 flex flex-wrap gap-2 text-xs text-slate-400">
                  <InlinePill>{yearLabel(paper.year)}</InlinePill>
                  <InlinePill>{paper.venue || 'No venue'}</InlinePill>
                  <InlinePill>{paper.doi || 'No DOI'}</InlinePill>
                </div>

                {paperNotes[paper.id]?.trim() ? (
                  <div className="mt-4 rounded-2xl border border-primary-400/20 bg-primary-500/10 p-4 text-sm leading-7 text-slate-100">
                    <div className="mb-2 text-xs uppercase tracking-[0.2em] text-slate-400">Notes</div>
                    {paperNotes[paper.id]}
                  </div>
                ) : null}

                <div className="mt-4 flex flex-wrap items-center gap-3">
                  <Link
                    href={`/paper/${encodePaperSlug(paper)}`}
                    className="inline-flex items-center gap-2 rounded-2xl bg-primary-500 px-4 py-3 text-sm font-semibold text-white transition hover:bg-primary-400"
                  >
                    <FileText size={16} />
                    Open details
                  </Link>
                  <a
                    href={paper.pdfUrl || paper.url}
                    target="_blank"
                    rel="noreferrer"
                    className="inline-flex items-center gap-2 rounded-2xl border border-white/10 bg-white/5 px-4 py-3 text-sm font-medium text-slate-100 transition hover:bg-white/10"
                  >
                    <Sparkles size={16} />
                    Open source
                  </a>
                </div>
              </article>
            ))}
          </div>
        ) : (
          <div className="rounded-3xl border border-dashed border-white/10 bg-white/5 p-10 text-center text-slate-300 shadow-soft">
            <Bookmark className="mx-auto mb-4 text-slate-500" size={24} />
            <div className="text-lg font-semibold text-white">No saved papers yet</div>
            <p className="mt-2 text-sm leading-7 text-slate-400">
              Search the platform and save papers to build your personal scientific library.
            </p>
          </div>
        )}
      </section>
    </PageShell>
  );
}
