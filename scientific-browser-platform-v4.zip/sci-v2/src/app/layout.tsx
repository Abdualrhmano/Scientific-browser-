import type { Metadata } from 'next';
import type { ReactNode } from 'react';
import './globals.css';

export const metadata: Metadata = {
  title: {
    default: 'Scientific Browser Platform',
    template: '%s • Scientific Browser Platform',
  },
  description:
    'A professional scientific research platform for papers, videos, translation, notes, and future AI workflows.',
  metadataBase: new URL('https://scientific.browser'),
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body>{children}</body>
    </html>
  );
}
