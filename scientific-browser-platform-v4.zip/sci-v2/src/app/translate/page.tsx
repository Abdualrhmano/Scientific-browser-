'use client';

import { useMemo, useState } from 'react';
import { useSearchParams } from 'next/navigation';
import { Languages, Loader2, Sparkles, Copy, ArrowRightLeft } from 'lucide-react';
import { PageShell, MetricCard, SectionHeading, InlinePill } from '@/shared/components/PageShell';
import { inferLanguage, translateScientificText } from '@/lib/translate';

const languageOptions = [
  { value: 'ar', label: 'Arabic' },
  { value: 'en', label: 'English' },
];

export default function TranslatePage() {
  const searchParams = useSearchParams();
  const [text, setText] = useState(searchParams.get('text') ?? '');
  const [sourceLanguage, setSourceLanguage] = useState<'auto' | 'ar' | 'en'>(searchParams.get('lang') === 'ar' ? 'ar' : searchParams.get('lang') === 'en' ? 'en' : 'auto');
  const [targetLanguage, setTargetLanguage] = useState<'ar' | 'en'>('ar');
  const [translatedText, setTranslatedText] = useState('');
  const [provider, setProvider] = useState<'mymemory' | 'fallback' | ''>('');
  const [loading, setLoading] = useState(false);
  const [copied, setCopied] = useState(false);

  const detectedLanguage = useMemo(() => inferLanguage(text || 'Scientific Browser'), [text]);

  async function handleTranslate() {
    const content = text.trim();
    if (!content) return;
    setLoading(true);
    try {
      const result = await translateScientificText({
        text: content,
        sourceLanguage: sourceLanguage === 'auto' ? undefined : sourceLanguage,
        targetLanguage,
      });
      setTranslatedText(result.translatedText);
      setProvider(result.provider);
      setTargetLanguage(result.targetLanguage as 'ar' | 'en');
    } finally {
      setLoading(false);
    }
  }

  return (
    <PageShell
      eyebrow="Translation lab"
      title="Scientific Translation"
      description="Translate abstracts, titles, and research notes without leaving the platform."
      action={<MetricCard label="Detected language" value={detectedLanguage === 'ar' ? 'Arabic' : 'English'} />}
    >
      <section className="grid gap-4 lg:grid-cols-3">
        <MetricCard label="Source" value={sourceLanguage === 'auto' ? 'Auto detect' : sourceLanguage.toUpperCase()} />
        <MetricCard label="Target" value={targetLanguage.toUpperCase()} />
        <MetricCard label="Engine" value={provider || 'Ready'} />
      </section>

      <section className="mt-6 grid gap-6 xl:grid-cols-[1.1fr_0.9fr]">
        <div className="rounded-3xl border border-white/10 bg-white/5 p-6 shadow-soft">
          <SectionHeading
            eyebrow="Input"
            title="Paste research text"
            description="Use it for titles, abstracts, notes, or short paragraphs."
          />
          <div className="mt-5 space-y-4">
            <textarea
              value={text}
              onChange={(event) => setText(event.target.value)}
              rows={14}
              placeholder="Paste your scientific text here..."
              className="w-full rounded-2xl border border-white/10 bg-[#0a1220] px-4 py-3 text-sm leading-7 text-slate-100 outline-none placeholder:text-slate-500 focus:border-primary-400/50"
            />

            <div className="grid gap-3 md:grid-cols-3">
              <label className="space-y-2 text-sm text-slate-300">
                <span className="text-xs uppercase tracking-[0.2em] text-slate-400">Source language</span>
                <select
                  value={sourceLanguage}
                  onChange={(event) => setSourceLanguage(event.target.value as 'auto' | 'ar' | 'en')}
                  className="w-full rounded-2xl border border-white/10 bg-[#0a1220] px-4 py-3 text-white outline-none"
                >
                  <option value="auto">Auto detect</option>
                  <option value="ar">Arabic</option>
                  <option value="en">English</option>
                </select>
              </label>

              <label className="space-y-2 text-sm text-slate-300">
                <span className="text-xs uppercase tracking-[0.2em] text-slate-400">Target language</span>
                <select
                  value={targetLanguage}
                  onChange={(event) => setTargetLanguage(event.target.value as 'ar' | 'en')}
                  className="w-full rounded-2xl border border-white/10 bg-[#0a1220] px-4 py-3 text-white outline-none"
                >
                  {languageOptions.map((language) => (
                    <option key={language.value} value={language.value}>
                      {language.label}
                    </option>
                  ))}
                </select>
              </label>

              <div className="flex items-end">
                <button
                  type="button"
                  onClick={handleTranslate}
                  disabled={loading || !text.trim()}
                  className="inline-flex w-full items-center justify-center gap-2 rounded-2xl bg-primary-500 px-4 py-3 text-sm font-semibold text-white transition hover:bg-primary-400 disabled:cursor-not-allowed disabled:opacity-70"
                >
                  {loading ? <Loader2 className="animate-spin" size={16} /> : <ArrowRightLeft size={16} />}
                  Translate
                </button>
              </div>
            </div>
          </div>
        </div>

        <div className="rounded-3xl border border-white/10 bg-white/5 p-6 shadow-soft">
          <SectionHeading
            eyebrow="Output"
            title="Translation preview"
            description="Ready to copy into notes, abstracts, and reading summaries."
          />
          <div className="mt-5 space-y-4">
            <div className="rounded-2xl border border-white/10 bg-[#0a1220] p-4">
              <div className="mb-3 flex items-center justify-between gap-3">
                <InlinePill>Translated text</InlinePill>
                <button
                  type="button"
                  onClick={async () => {
                    if (!translatedText) return;
                    await navigator.clipboard.writeText(translatedText);
                    setCopied(true);
                    window.setTimeout(() => setCopied(false), 1500);
                  }}
                  className="inline-flex items-center gap-2 rounded-xl border border-white/10 bg-white/5 px-3 py-2 text-xs font-medium text-slate-100 transition hover:bg-white/10"
                >
                  <Copy size={14} />
                  {copied ? 'Copied' : 'Copy'}
                </button>
              </div>
              <div className="whitespace-pre-line text-sm leading-7 text-slate-200">
                {translatedText || 'Your translation will appear here.'}
              </div>
            </div>

            <div className="rounded-2xl border border-white/10 bg-white/5 p-4 text-sm leading-7 text-slate-300">
              <div className="mb-2 text-xs uppercase tracking-[0.2em] text-slate-400">Next steps</div>
              Translate paper abstracts, reading notes, or teaching material. The translation provider is isolated behind an API route so it can later be replaced with a higher quality model or enterprise service without changing the UI.
            </div>

            <a
              href="/"
              className="inline-flex items-center justify-center gap-2 rounded-2xl border border-white/10 bg-white/5 px-4 py-3 text-sm font-medium text-slate-100 transition hover:bg-white/10"
            >
              <Sparkles size={16} />
              Back to search
            </a>
          </div>
        </div>
      </section>
    </PageShell>
  );
}
